// pull. popup · by SUNN. (Trithaset Chaimongkol)
const $ = (s) => document.querySelector(s);
const IS_MAC = /Mac/i.test(navigator.platform || navigator.userAgent);
const IS_SAFARI = !!(chrome.runtime.getManifest().browser_specific_settings || {}).safari;
const send = (msg) => chrome.runtime.sendMessage(msg).catch(e => ({ ok: false, error: e.message }));

// This page is always read fresh from disk, the background isn't: after an update on disk the
// browser can still be running the old background. Spot that and reload pull. once.
const POPUP_BUILD = '2.5.0';
(async () => {
  const r = await send({ type: 'build' });
  if (r && r.ok && r.build === POPUP_BUILD) return;
  if (r && !r.ok && !/unknown message/i.test(r.error || '')) return;   // background busy / not there: leave it
  const { selfReloadAt } = await chrome.storage.local.get('selfReloadAt');
  if (selfReloadAt && Date.now() - selfReloadAt < 60000) return;
  await chrome.storage.local.set({ selfReloadAt: Date.now() });
  document.body.insertAdjacentHTML('afterbegin', '<div style="position:fixed;inset:0;z-index:99;display:grid;place-items:center;background:#000;color:#f2f2f0;font:600 13px/1.5 system-ui;text-align:center;padding:24px">Finishing the update…<br><span style="color:#9a9a97;font-weight:400">pull. restarts in a second — open it again.</span></div>');
  setTimeout(() => chrome.runtime.reload(), 700);
})();

const DEFAULTS = { quality: 'best', container: 'mp4', subtitles: false, subLangs: 'en,th', cookies: 'none', fbLogin: true,
                   outDir: '', notify: true, h264: true, prefetch: true, convert: true, keepOriginal: false, capFmt: 'png', clipCapture: true, inPlayer: true, autoUpdate: true, editCodec: 'h264', board: true, loopFmt: 'gif', loopWidth: 640, audioFmt: 'mp3', project: '' };
const RES = [['best', 'BEST'], ['2160', '4K'], ['1440', '2K'], ['1080', '1080'], ['720', '720'], ['480', '480'], ['360', '360']];

let settings = {};
let hostOk = false;
let target = null;        // from Sites.parse: { site, key, url, title, thumb, isPlaylist, playlistOnly, badge }
let info = null;          // formats from yt-dlp
let mode = 'video';
let res = 'best';
let heights = null;       // null = unknown yet
let detectToken = 0;
let activeTabId = null;
let pageTabId = null;     // tab whose <video> we can capture from
let frame = null;         // { t, paused, vw, vh }
let manualUrl = null;     // a pasted link

init();

async function init() {
  settings = { ...DEFAULTS, ...((await chrome.storage.local.get('settings')).settings || {}) };
  if (['brave', 'chrome', 'edge'].includes(settings.cookies)) settings.cookies = 'self';
  fillSettings();
  if (settings.quality === 'audio') mode = 'audio'; else res = settings.quality;
  $('#optSubs').checked = !!settings.subtitles;
  $('#optConvert').checked = !!settings.convert;
  buildRes();
  bindSeg();

  const st = await send({ type: 'getState' });
  renderJobs(st?.jobs || {});

  detect(false);
  checkHost();
  setInterval(pollFrame, 400);
}

// ---------------- host ----------------
async function checkHost() {
  const hs = $('#hostStatus');
  hs.className = 'status busy'; hs.querySelector('b').textContent = 'link';
  const ping = await send({ type: 'ping' });
  if (!ping?.ok) {
    hostOk = false;
    hs.className = 'status bad'; hs.querySelector('b').textContent = 'no host';
    $('#stage').classList.add('hidden'); $('#empty').classList.add('hidden');
    $('#setup').classList.remove('hidden');
    $('#setupErr').textContent = ping?.error || '';
    if (IS_SAFARI) $('#setupSteps').innerHTML = '<li>Open <code>pull. Setup</code> on this Mac (it starts the helper)</li><li>Safari → Settings → Extensions → pull. → allow it on every website</li>';
    else if (IS_MAC) $('#setupSteps').innerHTML = '<li>Open <code>pull. Setup</code> again</li><li>Quit the browser fully and reopen</li>';
    return;
  }
  hostOk = true;
  const h = ping.host;
  const missing = ['ytdlp', 'ffmpeg'].filter(k => !h[k]);
  hs.className = 'status ' + (missing.length ? 'bad' : 'ok');
  hs.querySelector('b').textContent = missing.length ? 'no ' + missing.join('/') : 'ready';
  $('#hostDetail').textContent =
    `yt-dlp   ${h.ytdlp || '—'}\nffmpeg   ${h.ffmpeg ? 'ok' : '—'}\njs       ${h.js || '— install deno'}\nhost     ${h.host || '—'}\nfolder   ${h.outDir}`;
}

// ---------------- detection ----------------
const cleanTitle = t => (t || '').replace(/^\(\d+\)\s*/, '').replace(/\s+(?:[-|]\s+|on\s+)(YouTube|Facebook|TikTok|Vimeo|Instagram|Pinterest)$/, '').trim();

let pageAllFrames = false;  // embedded players live in iframes

async function pageState(tabId) {
  try {
    const res = await chrome.scripting.executeScript({ target: { tabId, allFrames: pageAllFrames }, func: pullPageVideo, args: ['state'] });
    const ok = res.filter(r => r && r.result && r.result.vw);
    return (ok.find(r => r.frameId === 0) || ok[0] || res[0] || {}).result || null;
  } catch { return null; }
}

async function findEmbeds(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: pullFindEmbeds });
    return (r && r.result) || [];
  } catch { return []; }
}

async function detect(force) {
  const token = ++detectToken;
  const btn = $('#btnDetect');
  btn.classList.add('spin');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTabId = tab?.id;
  let next = Sites.parse(tab?.url || '');
  pageTabId = null;
  pageAllFrames = false;
  if (tab && Sites.isSupportedPage(tab.url || '')) {
    const st = await pageState(tab.id);
    if (st) pageTabId = tab.id;
    // Facebook feed / TikTok For You: the video has its own permalink inside the post
    if (!next && st?.link) next = Sites.parse(st.link);
  }
  // any other page: an embedded Vimeo player (portfolios, client review pages…)
  if (!next && !manualUrl && tab && /^https?:/.test(tab.url || '') && !Sites.isSupportedPage(tab.url)) {
    const src = (await findEmbeds(tab.id))[0];
    const v = src && Sites.parse(src);
    if (v) {
      next = { ...v, referer: tab.url, badge: 'EMBED', embedTitle: cleanTitle(tab.title) };
      pageTabId = tab.id;
      pageAllFrames = true;
    }
  }
  if (!next && manualUrl) { next = Sites.parseAny(manualUrl); pageTabId = null; }
  if (next && next.needsResolve) {
    const r = await send({ type: 'resolve', url: next.url });
    const real = r?.ok && Sites.parse(r.url);
    if (real && !real.needsResolve) next = { ...real, badge: real.badge || next.badge };
  }
  if (token !== detectToken) return;

  if (!next) {
    target = null;
    if ($('#setup').classList.contains('hidden')) { $('#stage').classList.add('hidden'); $('#empty').classList.remove('hidden'); }
    btn.classList.remove('spin');
    return;
  }
  if (target && target.key === next.key && !force) { btn.classList.remove('spin'); return; }

  const stage = $('#stage');
  if (!stage.classList.contains('hidden') && target) { stage.classList.add('swap'); await wait(180); }
  if (token !== detectToken) return;

  target = { ...next, title: next.site !== 'other' && tab && Sites.parse(tab.url || '') ? cleanTitle(tab.title) : '' };
  loadTrim();
  info = null;
  heights = null;
  $('#empty').classList.add('hidden');
  if ($('#setup').classList.contains('hidden')) stage.classList.remove('hidden');

  const img = $('#vThumb');
  img.classList.remove('ok');
  img.removeAttribute('src');
  $('.thumb').classList.remove('vertical');
  $('#vBg').style.backgroundImage = '';
  $('.thumb').classList.add('loading');
  if (target.thumb) setThumb(target.thumb);
  const SITE = { facebook: 'Facebook', tiktok: 'TikTok', vimeo: 'Vimeo', instagram: 'Instagram', pinterest: 'Pinterest' }[target.site];
  if (!target.title && target.embedTitle) target.title = target.embedTitle;
  $('#vTitle').textContent = target.title || (SITE ? SITE + ' video' : target.url);
  $('#vChan').textContent = SITE || '';
  $('#vDur').textContent = '';
  $('#vBadge').textContent = target.badge || '';
  setNote('reading', true);
  $('#plWrap').classList.toggle('hidden', !target.isPlaylist);
  $('#optPlaylist').checked = !!target.playlistOnly;
  $('#optPlaylist').disabled = !!target.playlistOnly;
  buildRes();
  updateCapture();
  requestAnimationFrame(() => { stage.classList.remove('swap'); placePills(); });

  if (target.playlistOnly) {
    $('#vTitle').textContent = cleanTitle(tab?.title) || 'Playlist';
    $('.thumb').classList.remove('loading');
    setNote('playlist');
    heights = [];
    buildRes();
    btn.classList.remove('spin');
    return;
  }

  if (['youtube', 'tiktok', 'vimeo'].includes(target.site)) {
    send({ type: 'meta', url: target.url }).then(r => {
      if (token !== detectToken || !r?.ok || !r.meta) return;
      $('#vTitle').textContent = target.title = r.meta.title || target.title;
      $('#vChan').textContent = r.meta.uploader || '';
      if (!target.thumb && r.meta.thumbnail) setThumb(target.thumb = r.meta.thumbnail);
    });
  }

  const r = await send({ type: 'formats', url: target.url, force, referer: target.referer || '' });
  if (token !== detectToken) return;
  $('.thumb').classList.remove('loading');
  btn.classList.remove('spin');
  if (!r?.ok) {
    heights = [];
    setNote(hostOk ? ({ facebook: 'needs FB login?', vimeo: 'private / embed-only?', instagram: 'log in to Instagram?', pinterest: 'private pin?' }[target.site] || 'formats n/a') : '');
    $('#vNote').title = r?.error || '';
    buildRes();
    return;
  }
  info = r.info;
  if (info.title) $('#vTitle').textContent = target.title = info.title;
  if (info.uploader) $('#vChan').textContent = info.uploader;
  if (!target.thumb && info.thumbnail) setThumb(target.thumb = info.thumbnail);
  $('#vDur').textContent = info.is_live ? 'LIVE' : info.duration ? fmtDur(info.duration) : '';
  heights = info.heights || [];
  const max = heights.length ? Math.max(...heights) : 0;
  setNote(info.image ? `image${info.maxW ? ' · ' + info.maxW + '×' + info.maxH : ''}` : max ? `max ${max >= 2160 ? '4K' : max + 'p'}${info.fps60 ? ' · 60' : ''}` : '');
  buildRes();
  updateCapture();
}

function setThumb(src) {
  const img = $('#vThumb');
  img.onload = () => {
    img.classList.add('ok');
    const tall = img.naturalHeight > img.naturalWidth * 1.05;
    $('.thumb').classList.toggle('vertical', tall);
    $('#vBg').style.backgroundImage = tall ? `url("${src.replace(/"/g, '%22')}")` : '';
  };
  img.src = src;
}

function setNote(text, waiting = false) {
  const n = $('#vNote');
  n.textContent = text;
  n.classList.toggle('wait', waiting);
}

// ---------------- frame capture ----------------
async function pollFrame() {
  if (!pageTabId || !target || document.hidden) return;
  const st = await pageState(pageTabId);
  frame = st && st.vw ? st : null;
  updateCapture();
}

function updateCapture() {
  updateStills();
  const ok = !!(frame && target && !target.playlistOnly && hostOk !== false);
  $('#btnCapture').disabled = !ok;
  $('#btnSnip').disabled = !ok;
  const chip = $('#vTime');
  if (!frame || !target) { chip.textContent = ''; $('#capInfo').innerHTML = ''; return; }
  chip.textContent = (frame.paused ? '❚❚ ' : '▶ ') + fmtTime(frame.t);
  chip.classList.toggle('live', !frame.paused);
  const w = info?.maxW, h = info?.maxH;
  const size = w && h ? `${w}×${h}` : 'max res';
  $('#capInfo').innerHTML = `<span>FRAME ${fmtTime(frame.t)}</span><span>→ ${size} ${settings.capFmt.toUpperCase()}</span><span class="kbd">${IS_MAC ? '⌥⇧S' : 'ALT+SHIFT+S'}</span>`;
}

// ---------------- stills (whole clip) ----------------
let stillEvery = 5;
function clipDuration() { return (info && info.duration) || (frame && isFinite(frame.dur) ? frame.dur : 0) || 0; }
function updateStills() {
  const ok = !!(target && !target.playlistOnly && hostOk !== false && mode === 'video');
  $('#stills').classList.toggle('off', !ok);
  $('#btnStills').disabled = !ok;
  const d = clipDuration();
  if (typeof syncRange === 'function') syncRange();
  const est = stillEvery === 'shots' ? '1 per shot + AE markers' : d ? '≈ ' + (Math.floor(Math.max(0, d - 0.5) / stillEvery) + 1) + ' frames' : '';
  $('#stEst').textContent = stillEvery === 'shots' ? '1/shot' : est.replace(' frames', ' fr');
  $('#stEst').title = est;
}
$('#segStill').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  stillEvery = b.dataset.v === 'shots' ? 'shots' : +b.dataset.v;
  $('#segStill').querySelectorAll('button').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', String(x === b)); });
  chrome.storage.local.set({ stillEvery });
  updateStills();
};
chrome.storage.local.get('stillEvery').then(({ stillEvery: v }) => {
  if (v) { stillEvery = v; $('#segStill').querySelectorAll('button').forEach(x => x.classList.toggle('on', String(x.dataset.v) === String(v))); }
  updateStills();
});
$('#btnStills').onclick = async () => {
  if (!target) return;
  const b = $('#btnStills'); b.textContent = 'Added'; setTimeout(() => b.textContent = 'Generate', 1400);
  await send({ type: 'stills', tabId: pageTabId, url: target.url, title: target.title || 'stills', interval: stillEvery === 'shots' ? 0 : stillEvery,
               mode: stillEvery === 'shots' ? 'shots' : 'interval', duration: clipDuration() });
};

$('#btnCapture').onclick = async () => {
  if (!frame || !target) return;
  const b = $('#btnCapture');
  b.classList.remove('shot'); void b.offsetWidth; b.classList.add('shot');
  await send({ type: 'capture', tabId: pageTabId, url: target.url, title: target.title || 'capture', time: frame.t, referer: target.referer || '' });
};

// snip: the box is drawn on the page, so hand over to the tab and get out of the way
$('#btnSnip').onclick = async () => {
  if (!frame || !target) return;
  const r = await send({ type: 'snipStart', tabId: pageTabId });
  if (r && r.ok) window.close();
};

// ---------------- segmented controls ----------------
function buildRes() {
  const seg = $('#segRes');
  seg.querySelectorAll('button').forEach(b => b.remove());
  const max = heights && heights.length ? Math.max(...heights) : 0;
  RES.forEach(([v, label], idx) => {
    const b = document.createElement('button');
    b.dataset.v = v;
    b.textContent = label;
    b.style.setProperty('--i', idx);
    if (heights === null && v !== 'best') b.classList.add('pending');
    else if (v !== 'best' && heights && heights.length && +v > max + 10) b.disabled = true;
    seg.appendChild(b);
  });
  const cur = seg.querySelector(`button[data-v="${res}"]`);
  if (heights !== null && cur?.disabled) res = 'best';
  syncSeg();
}

function bindSeg() {
  $('#segMode').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    mode = b.dataset.v; syncSeg();
  });
  $('#segRes').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b || b.disabled) return;
    res = b.dataset.v; syncSeg();
  });
  $('#segAud').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    settings.audioFmt = b.dataset.v; chrome.storage.local.set({ settings }); syncSeg();
  });
  window.addEventListener('resize', placePills);
}

// 2K/4K on YouTube only exists as VP9/AV1 → offer the H.264 conversion right there
function hiRes() {
  const max = heights && heights.length ? Math.max(...heights) : 0;
  return mode === 'video' && (res === '2160' || res === '1440' || (res === 'best' && !settings.h264 && max > 1080));
}
// ProRes / DNxHR can be asked for at any size; H.264 only matters above 1080p (YouTube serves 2K/4K as VP9/AV1)
const editLabel = () => ({ prores: '→ ProRes 422', dnxhr: '→ DNxHR HQ' }[settings.editCodec] || '→ H.264 MP4');
const wantsConvert = () => mode === 'video' && (hiRes() || (settings.editCodec && settings.editCodec !== 'h264'));

function syncSeg() {
  if (typeof updateStills === 'function') setTimeout(updateStills);
  $('#segMode').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === mode));
  $('#segRes').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === res));
  $('#resWrap').classList.toggle('collapsed', mode === 'audio');
  $('#audWrap').classList.toggle('collapsed', mode !== 'audio');
  $('#segAud').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === (settings.audioFmt === 'wav' ? 'wav' : 'mp3')));
  $('#cvWrap').classList.toggle('hidden', !wantsConvert());
  $('#cvLabel').textContent = editLabel();
  placePills();
}

function placePills() {
  for (const seg of [$('#segMode'), $('#segRes'), $('#segAud')]) {
    const on = seg.querySelector('button.on');
    const pill = seg.querySelector('.pill');
    if (!on || !on.offsetWidth) continue;
    pill.style.width = on.offsetWidth + 'px';
    pill.style.transform = `translateX(${on.offsetLeft}px)`;
  }
}

// ---------------- range (IN / OUT) ----------------
function parseT(s) {
  s = String(s || '').trim().replace(',', '.');
  if (!s) return null;
  const p = s.split(':').map(Number);
  if (p.some(x => !isFinite(x) || x < 0)) return null;
  return p.reduce((a, x) => a * 60 + x, 0);
}
function fmtT(t) {
  const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
  const ss = (s < 10 ? '0' : '') + s.toFixed(1).replace(/\.0$/, '');
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + ss;
}
const rangeOn = () => $('#optRange').checked && !$('#optPlaylist').checked && !!target && !target.playlistOnly;
function rangeVal() {
  const a = parseT($('#rgIn').value) ?? 0, b = parseT($('#rgOut').value);
  return b != null && b > a ? { start: a, end: b } : null;
}
function syncRange() {
  const on = rangeOn();
  $('#rangeRow').classList.toggle('hidden', !on);
  const v = rangeVal();
  $('#rgLen').textContent = v ? (v.end - v.start).toFixed(1) + 's' : on ? 'set OUT' : '';
  $('#rgLen').classList.toggle('bad', on && !v);
  $('#btnDownload').disabled = on && !v;
  const longLoop = v && v.end - v.start > 30;
  $('#btnLoop').disabled = !v || longLoop;
  $('#btnLoop').textContent = (settings.loopFmt === 'webp' ? 'WEBP' : 'GIF');
  $('#btnLoop').title = longLoop ? 'Loops are up to 30 s — tighten IN / OUT' : 'Make a looping ' + $('#btnLoop').textContent + ' of IN → OUT (up to 30 s)';
}
$('#optRange').addEventListener('change', () => {
  if ($('#optRange').checked && !$('#rgIn').value && frame) $('#rgIn').value = fmtT(frame.t);
  syncRange(); saveTrim();
});
$('#optPlaylist').addEventListener('change', syncRange);
['#rgIn', '#rgOut'].forEach(q => $(q).addEventListener('input', () => { syncRange(); saveTrim(); }));
$('#rgSetIn').onclick = () => { if (frame) { $('#rgIn').value = fmtT(frame.t); syncRange(); saveTrim(); } };
$('#rgSetOut').onclick = () => { if (frame) { $('#rgOut').value = fmtT(frame.t); syncRange(); saveTrim(); } };

// IN / OUT picked on the video's own timeline: player.js saves { key, url, start, end } as "trim", and the Range
// fields here write back to it, so the brackets on the page follow what's typed
const trimFor = tv => !!(target && tv && (tv.key === target.key || tv.url === target.url) && tv.end > tv.start && Date.now() - (tv.at || 0) < 12 * 3600e3);
function applyTrim(tv) {
  if (!trimFor(tv)) return;
  $('#optRange').checked = true;
  if (document.activeElement !== $('#rgIn')) $('#rgIn').value = fmtT(tv.start);
  if (document.activeElement !== $('#rgOut')) $('#rgOut').value = fmtT(tv.end);
  syncRange();
}
function loadTrim() { chrome.storage.local.get('trim').then(({ trim }) => applyTrim(trim)).catch(() => {}); }
function saveTrim() {
  if (!target || target.playlistOnly) return;
  if (!$('#optRange').checked) {
    chrome.storage.local.get('trim').then(({ trim }) => { if (trimFor(trim)) chrome.storage.local.remove('trim'); }).catch(() => {});
    return;
  }
  const v = rangeVal();
  if (v) chrome.storage.local.set({ trim: { key: target.key, url: target.url, start: v.start, end: v.end, at: Date.now() } }).catch(() => {});
}
chrome.storage.onChanged.addListener(ch => {
  if (!ch.trim) return;
  if (ch.trim.newValue) applyTrim(ch.trim.newValue);
  else if (trimFor(ch.trim.oldValue) && $('#optRange').checked) { $('#optRange').checked = false; syncRange(); }
});

$('#btnLoop').onclick = async () => {
  const v = rangeVal();
  if (!target || !v) return;
  const b = $('#btnLoop'), label = b.textContent;
  b.textContent = 'ADDED'; setTimeout(() => b.textContent = label, 1400);
  await send({ type: 'loop', url: target.url, title: target.title || 'loop', start: v.start, end: v.end });
};
$('#btnCover').onclick = async () => {
  if (!target || target.playlistOnly) return;
  const b = $('#btnCover');
  b.textContent = 'ADDED'; b.classList.add('sent');
  setTimeout(() => { b.textContent = 'COVER ↓'; b.classList.remove('sent'); }, 1400);
  await send({ type: 'thumb', url: target.url, title: target.title || 'cover' });
};
async function openBoard(day) {
  const r = await send({ type: 'openBoard', day: day || '' });
  if (r?.ok) window.close();
}
$('#btnBoard').onclick = () => openBoard();
$('#btnHdrBoard').onclick = () => openBoard();

$('#optConvert').addEventListener('change', () => { settings.convert = $('#optConvert').checked; $('#sConvert').checked = settings.convert; saveSettings(); });

// ---------------- download ----------------
$('#btnDownload').onclick = async () => {
  if (!target) return;
  const btn = $('#btnDownload');
  if (btn.classList.contains('sent')) return;
  const quality = mode === 'audio' ? 'audio' : res;
  const r = await send({
    type: 'download', url: target.url, title: target.title || target.url, thumb: target.thumb,
    options: { quality, audioFmt: settings.audioFmt === 'wav' ? 'wav' : 'mp3', subtitles: $('#optSubs').checked, playlist: $('#optPlaylist').checked, convert: wantsConvert() && $('#optConvert').checked,
               referer: target.referer || '', section: rangeOn() ? rangeVal() : null },
  });
  btn.classList.toggle('fail', !r?.ok);
  btn.classList.add('sent');
  setTimeout(() => btn.classList.remove('sent', 'fail'), 1400);
};

// ---------------- paste a link ----------------
function useLink(raw) {
  const t = Sites.parseAny((raw || '').trim());
  if (!t) { $('#linkIn').classList.add('bad'); setTimeout(() => $('#linkIn').classList.remove('bad'), 600); return false; }
  manualUrl = t.url;
  detect(true);
  return true;
}
$('#linkForm').addEventListener('submit', e => { e.preventDefault(); if (!toBatch($('#linkIn').value)) useLink($('#linkIn').value); });
document.addEventListener('paste', e => {
  if (e.target.closest && e.target.closest('input, select, textarea')) return;
  const text = e.clipboardData?.getData('text') || '';
  if (toBatch(text)) { e.preventDefault(); return; }
  if (/^https?:\/\//.test(text.trim())) { e.preventDefault(); useLink(text); }
});

// ---------------- several links at once ----------------
function batchLinks(text) {
  const seen = new Set(), out = [];
  for (const raw of String(text || '').match(/https?:\/\/[^\s"'<>]+/g) || []) {
    const t = Sites.parseAny(raw.replace(/[),.;]+$/, ''));
    if (t && !seen.has(t.key || t.url)) { seen.add(t.key || t.url); out.push(t); }
  }
  return out;
}
// more than one link pasted: open the batch box with them instead of loading just the first
function toBatch(text) {
  if (batchLinks(text).length < 2) return false;
  $('#batch').classList.remove('hidden');
  $('#batchIn').value = text.trim();
  syncBatch();
  return true;
}
function syncBatch() {
  const n = batchLinks($('#batchIn').value).length;
  $('#batchN').textContent = n === 1 ? '1 link' : n + ' links';
  $('#batchGo').disabled = !n;
  $('#batchGo').textContent = n > 1 ? 'Add ' + n + ' to queue' : 'Add to queue';
}
$('#btnLinks').onclick = () => { const b = $('#batch'); b.classList.toggle('hidden'); if (!b.classList.contains('hidden')) $('#batchIn').focus(); };
$('#batchIn').addEventListener('input', syncBatch);
$('#batch').addEventListener('submit', async e => {
  e.preventDefault();
  const list = batchLinks($('#batchIn').value);
  if (!list.length) return;
  const quality = mode === 'audio' ? 'audio' : res;
  $('#batchGo').disabled = true;
  for (const t of list) {
    // a quick title lookup so the queue doesn't show bare links
    const m = await Promise.race([send({ type: 'meta', url: t.url }), new Promise(r => setTimeout(r, 2500))]);
    await send({ type: 'download', url: t.url, title: m?.meta?.title || t.title || t.url, options: { quality, audioFmt: settings.audioFmt === 'wav' ? 'wav' : 'mp3', subtitles: $('#optSubs').checked } });
  }
  $('#batchIn').value = '';
  syncBatch();
  $('#batch').classList.add('hidden');
});

// ---------------- queue (keyed, updates in place) ----------------
const jobEls = new Map();
chrome.runtime.onMessage.addListener(m => { if (m.type === 'state') renderJobs(m.jobs); });

let lastJobs = {};
function renderJobs(jobs) {
  lastJobs = jobs || {};
  const box = $('#jobs');
  const list = Object.values(jobs).sort((a, b) => b.created - a.created);
  const active = list.filter(j => j.status === 'running' || j.status === 'queued').length;
  $('#qCount').textContent = list.length ? (active ? active + '/' : '') + list.length : '';

  for (const [id, el] of jobEls) if (!jobs[id]) { el.remove(); jobEls.delete(id); }
  if (!list.length) {
    if (!box.querySelector('.q-empty')) box.innerHTML = '<div class="q-empty">EMPTY</div>';
    return;
  }
  box.querySelector('.q-empty')?.remove();

  list.forEach((j, idx) => {
    let el = jobEls.get(j.id);
    if (!el) { el = makeJob(j); jobEls.set(j.id, el); }
    updateJob(el, j);
    if (box.children[idx] !== el) box.insertBefore(el, box.children[idx] || null);
  });
}

const CODEC_TAG = { prores: 'PRORES', dnxhr: 'DNXHR' };
const qTag = (q, j) => q === 'audio' ? (j?.opts?.audioFmt === 'wav' ? 'WAV' : 'MP3') : q === 'best' ? 'BEST' : q === '2160' ? '4K' : q === '1440' ? '2K' : q;
const extOf = f => (f || '').split('.').pop().toLowerCase();

function makeJob(j) {
  const el = document.createElement('div');
  el.className = 'job';
  el.innerHTML = `
    <div class="job-top"><span class="kind"></span><div class="job-title"></div><span class="tag"></span></div>
    <div class="prog"><div class="dots">${Array.from({ length: 28 }, (_, i) => `<i style="--i:${i}"></i>`).join('')}</div><i class="live"></i><div class="pct"></div></div>
    <div class="job-bot"><span class="l"></span><span class="acts"></span></div>`;
  el.querySelector('.kind').innerHTML = j.kind === 'capture'
    ? '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16"/><circle cx="12" cy="12" r="3"/></svg>'
    : j.kind === 'stills'
      ? '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="7" height="7" rx="1.5"/><rect x="14" y="4" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>'
    : j.kind === 'convert'
      ? '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h13l-3-3M20 17H7l3 3"/></svg>'
      : '';
  return el;
}

const BUSY_PHASES = ['making gif', 'making webp', 'trimming', 'merging', 'finishing', 'picking', 'reading', 'reading page', 'finding source', 'grabbing', 'grabbing from page', 'contact sheet'];

// rolling percentage: three 0–9 strips (leading zeros hidden) slide to the new value
function odo(el, n) {
  let o = el.querySelector('.odo');
  if (!o) {
    el.textContent = '';
    o = document.createElement('span'); o.className = 'odo';
    for (let k = 0; k < 3; k++) {
      const d = document.createElement('span'); d.className = 'dg';
      d.innerHTML = Array.from({ length: 10 }, (_, i) => `<span>${i}</span>`).join('');
      o.appendChild(d);
    }
    el.appendChild(o);
    el.insertAdjacentHTML('beforeend', '<small>%</small>');
  }
  const s = String(Math.max(0, Math.min(100, n))).padStart(3, ' ');
  [...o.children].forEach((d, k) => {
    const c = s[k];
    d.classList.toggle('off', c === ' ');
    d.style.transform = `translateY(${-(c === ' ' ? 0 : +c)}em)`;
  });
}

function updateJob(el, j) {
  const t = el.querySelector('.job-title');
  if (t.textContent !== j.title) { t.textContent = j.title; t.title = j.title; }
  el.querySelector('.tag').textContent = j.kind === 'loop' ? (j.format || 'gif').toUpperCase() : j.kind === 'thumb' ? 'COVER' : j.kind === 'download' && j.section ? 'RANGE' : j.kind === 'stills' ? (j.mode === 'shots' ? 'SHOTS' : 'EVERY ' + j.interval + 'S') : j.kind === 'capture' ? (j.file ? extOf(j.file).toUpperCase() : 'CAP')
    : j.kind === 'convert' ? (CODEC_TAG[settings.editCodec] || 'H.264') : qTag(j.quality, j) + (j.convert ? ' → ' + (CODEC_TAG[j.opts?.editCodec] || 'H.264') : '');

  const busy = j.status === 'running' && (j.percent == null || BUSY_PHASES.includes(j.phase) || (j.phase === 'converting' && !j.percent));
  const indet = j.status === 'queued' || busy;
  el.className = `job ${j.status}${indet ? ' indet' : ''}`;

  const p = j.status === 'done' ? 100 : Math.max(0, Math.min(100, j.percent || 0));
  const filled = Math.round(p / 100 * 28);
  el.querySelectorAll('.dots i').forEach((d, i) => {
    d.className = indet ? '' : i < filled ? 'f' : (i === filled && j.status === 'running' ? 'h' : '');
  });

  const pct = el.querySelector('.pct');
  if (j.status === 'done') pct.innerHTML = ['capture', 'stills', 'loop', 'thumb'].includes(j.kind) ? '✓' : '100<small>%</small>';
  else if (j.status === 'error') pct.textContent = 'ERR';
  else if (j.status === 'cancelled') pct.textContent = '—';
  else if (indet) pct.textContent = '···';
  else odo(pct, Math.floor(p));

  let left = '';
  if (j.status === 'queued') left = j.kind === 'convert' ? 'choose a file' : 'starting';
  else if (j.status === 'running') {
    if (busy) left = j.phase === 'picking' ? 'choose a file' : (j.phase || 'starting');
    else if (j.via === 'browser' && j.phase === 'download') left = ['browser mode', j.speed, j.eta && 'eta ' + j.eta].filter(Boolean).join('  ·  ');
    else left = [j.phase === 'converting' ? 'converting' : '', j.speed, j.eta && 'eta ' + j.eta].filter(Boolean).join('  ·  ');
  }
  else if (j.status === 'done') {
    if (j.kind === 'capture') left = [j.crop && 'snip', j.width && `${j.width}×${j.height}`, j.lowRes && 'player quality', j.copied && 'copied', j.board && 'on board'].filter(Boolean).join('  ·  ');
    else if (j.kind === 'loop' || j.kind === 'thumb') left = [j.width && `${j.width}×${j.height}`, j.size && fmtSize(j.size)].filter(Boolean).join('  ·  ') || 'saved';
    else if (j.kind === 'stills') left = (j.count || 0) + (j.mode === 'shots' ? ' shots  ·  AE markers' : ' frames') + (j.sheet ? '  ·  contact sheet' : '');
    else left = j.note || ('saved' + (j.size ? '  ·  ' + fmtSize(j.size) : '') + (j.via === 'browser' ? '  ·  browser mode' : ''));
  }
  else if (j.status === 'cancelled') left = 'cancelled';
  else if (j.status === 'error') left = 'failed';
  el.querySelector('.l').textContent = left;

  const acts = el.querySelector('.acts');
  const key = j.status + (j.file || '');
  if (acts.dataset.k !== key) {
    acts.dataset.k = key;
    acts.innerHTML = '';
    if (j.status === 'running' || j.status === 'queued') acts.appendChild(btn('Cancel', () => send({ type: 'cancel', id: j.id })));
    if (j.status === 'done' && j.file) {
      if (j.kind === 'capture') acts.appendChild(btn('Copy', e => { send({ type: 'clip', path: j.file }); e.target.textContent = 'Copied'; }));
      if (j.kind === 'capture' && j.board) acts.appendChild(btn('Board', () => openBoard((String(j.board).match(/(\d{4}-\d{2}-\d{2})/) || [])[1])));
      if (j.kind === 'stills' && j.sheet) acts.appendChild(btn('Sheet', () => send({ type: 'reveal', path: j.sheet })));
      if (j.kind === 'download' && ['mkv', 'webm'].includes(extOf(j.file))) acts.appendChild(btn('→ MP4', () => send({ type: 'convert', path: j.file })));
      if (j.kind === 'download' && ['mp4', 'mkv', 'webm'].includes(extOf(j.file)) && settings.editCodec && settings.editCodec !== 'h264')
        acts.appendChild(btn(settings.editCodec === 'prores' ? '→ ProRes' : '→ DNxHR', () => send({ type: 'convert', path: j.file })));
      acts.appendChild(btn('Show', () => send({ type: 'reveal', path: j.file })));
    }
    if (j.status === 'error' && j.file) acts.appendChild(btn('Show', () => send({ type: 'reveal', path: j.file })));
    if ((j.status === 'error' || j.status === 'cancelled') && j.kind === 'download')
      acts.appendChild(btn('Retry', () => send({ type: 'download', url: j.url, title: j.title, thumb: j.thumb, options: { quality: j.quality, convert: j.convert, section: j.section } })));
    if ((j.status === 'error' || j.status === 'cancelled') && j.kind === 'convert' && j.src)
      acts.appendChild(btn('Retry', () => send({ type: 'convert', path: j.src })));
  }

  let err = el.querySelector('.job-err');
  if (j.status === 'error') {
    if (!err) { err = document.createElement('div'); err.className = 'job-err'; el.appendChild(err); }
    err.textContent = hint(j.error, j) + (j.browserError ? '\n(browser mode: ' + j.browserError + ')' : '');
  } else err?.remove();

  let pw = el.querySelector('.pw');
  if (j.status === 'error' && j.kind === 'download' && /password/i.test(j.error || '')) {
    if (!pw) {
      pw = document.createElement('form');
      pw.className = 'pw';
      pw.innerHTML = '<input type="password" placeholder="Video password" autocomplete="off"><button type="submit">Unlock</button>';
      pw.onsubmit = e => {
        e.preventDefault();
        const v = pw.querySelector('input').value;
        if (!v) return;
        send({ type: 'download', url: j.url, title: j.title, thumb: j.thumb,
               options: { quality: j.quality, convert: j.convert, referer: j.opts?.referer || '', videoPassword: v } });
      };
      el.appendChild(pw);
      setTimeout(() => pw.querySelector('input').focus(), 50);
    }
  } else pw?.remove();
}

function hint(err = '', j = {}) {
  const last = String(err).split('\n').filter(Boolean).slice(-2).join(' ');
  const fb = /facebook|fb\.watch/.test(j.url || '');
  const tk = /tiktok/.test(j.url || '');
  const vm = /vimeo/.test(j.url || '');
  if (vm && /password/i.test(err)) return 'This Vimeo is password-protected — enter the password:';
  if (vm && /embed.?only|embedding URL|only be (played|embedded)|Referer/i.test(err)) return 'This Vimeo only plays where it\'s embedded. Open that page and use pull. there.';
  if (vm && /log(ged)? ?in|private|authenticat/i.test(err)) return 'Private Vimeo — log in to Vimeo in this browser (Settings → Site logins on), then Retry.';
  if (tk && /IP address is blocked|status code 10204/i.test(err)) return 'TikTok blocked this from your connection. Try again later, or with a VPN.';
  if (tk && /permission|login|private|10216|10222/i.test(err)) return 'Private TikTok — log in to TikTok in this browser (Settings → Site logins on), then Retry.';
  if (tk && /Unable to extract|Unable to find|Video not available|status code/i.test(err)) return 'TikTok changed something. Settings → Update yt-dlp, then Retry.';
  if (fb && /login|log in|cookies|private|unavailable|Cannot parse data/i.test(err)) return 'Facebook needs your login. Log in to Facebook in this browser (Settings → Facebook login on), then Retry.';
  if (/not a bot|Sign in to confirm/i.test(err)) return 'YouTube wants a login. Settings → YouTube login → "This browser", then Retry.';
  if (/cookie|DPAPI|decrypt/i.test(err)) return 'Couldn\'t read the login. Settings → YouTube login → "This browser", then Retry.';
  if (/Only images are available|Requested format is not available|nsig|n challenge|js runtime|JavaScript runtime/i.test(err)) return 'Format extraction failed. Settings → Update yt-dlp, and make sure deno is installed.';
  if (/ffmpeg not found|ffprobe not found/i.test(err)) return 'ffmpeg is missing — run pull-setup.exe again.';
  if (/WinError 5|WinError 32|Access is denied|being used by another process/i.test(err)) return 'Windows locked the file while saving (Explorer preview or antivirus). Retry — v2.2.0 works in a private folder so this shouldn\'t repeat.';
  return last.slice(0, 260);
}

function btn(text, fn) { const b = document.createElement('button'); b.textContent = text; b.onclick = fn; return b; }
function fmtDur(s) { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); }
function fmtTime(s) {
  s = Math.max(0, s || 0);
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = (s % 60).toFixed(2).padStart(5, '0');
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + x;
}
function fmtSize(b) { return b > 1e9 ? (b / 1e9).toFixed(2) + ' GB' : (b / 1e6).toFixed(1) + ' MB'; }
const wait = ms => new Promise(r => setTimeout(r, ms));

$('#btnClear').onclick = () => send({ type: 'clear' });
$('#btnOpenDir').onclick = () => send({ type: 'openDir' });
$('#btnConvert').onclick = () => send({ type: 'convert' });

// ---------------- detect button + live tab follow ----------------
$('#btnDetect').onclick = () => detect(true);
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (tabId === activeTabId && (change.url || change.status === 'complete')) detect(false);
});
chrome.tabs.onActivated.addListener(() => { manualUrl = null; detect(false); });

// ---------------- settings sheet ----------------
function openSheet(open) {
  document.body.classList.toggle('sheet-open', open);
  $('#btnSettings').classList.toggle('on', open);
  $('#sheet').setAttribute('aria-hidden', String(!open));
}
$('#btnSettings').onclick = () => openSheet(!document.body.classList.contains('sheet-open'));
$('#btnDone').onclick = () => openSheet(false);
$('#scrim').onclick = () => openSheet(false);
document.addEventListener('keydown', e => { if (e.key === 'Escape') openSheet(false); });

function fillSettings() {
  $('#sCookies').value = settings.cookies;
  $('#sOut').value = settings.outDir;
  $('#sContainer').value = settings.container;
  $('#sSubLangs').value = settings.subLangs;
  $('#sDefault').value = settings.quality;
  $('#sNotify').checked = settings.notify;
  $('#sH264').checked = settings.h264;
  $('#sPrefetch').checked = settings.prefetch;
  $('#sCapFmt').value = settings.capFmt;
  $('#sClip').checked = settings.clipCapture;
  $('#sFb').checked = settings.fbLogin;
  $('#sConvert').checked = settings.convert;
  $('#sKeep').checked = settings.keepOriginal;
  $('#sInPlayer').checked = settings.inPlayer !== false;
  $('#sEdit').value = settings.editCodec || 'h264';
  $('#sAutoUpd').checked = settings.autoUpdate !== false;
  $('#sBoard').checked = settings.board !== false;
  $('#sLoopFmt').value = settings.loopFmt === 'webp' ? 'webp' : 'gif';
  $('#sLoopW').value = String(settings.loopWidth || 640);
  $('#sProject').value = settings.project || '';
  syncProject();
}
function syncProject() {
  const c = $('#projChip'), p = (settings.project || '').trim();
  c.textContent = p; c.title = 'Project: ' + p + ' — saving to its own folder. Change in Settings';
  c.classList.toggle('hidden', !p);
}
$('#projChip').onclick = () => { $('#btnSettings').click(); setTimeout(() => $('#sProject').focus(), 350); };

async function saveSettings() {
  settings = {
    ...settings,
    cookies: $('#sCookies').value, outDir: $('#sOut').value.trim(), container: $('#sContainer').value,
    subLangs: $('#sSubLangs').value.trim() || 'en', quality: $('#sDefault').value,
    notify: $('#sNotify').checked, h264: $('#sH264').checked, prefetch: $('#sPrefetch').checked,
    capFmt: $('#sCapFmt').value, clipCapture: $('#sClip').checked, fbLogin: $('#sFb').checked,
    convert: $('#sConvert').checked, keepOriginal: $('#sKeep').checked, inPlayer: $('#sInPlayer').checked, editCodec: $('#sEdit').value, autoUpdate: $('#sAutoUpd').checked,
    subtitles: $('#optSubs').checked,
    board: $('#sBoard').checked, loopFmt: $('#sLoopFmt').value, loopWidth: +$('#sLoopW').value,
    project: $('#sProject').value.trim(),
  };
  syncProject();
  syncRange();
  $('#optConvert').checked = settings.convert;
  $('#cvLabel').textContent = editLabel();
  syncSeg();
  updateCapture();
  await chrome.storage.local.set({ settings });
}
document.querySelectorAll('#sheet select, #sheet input').forEach(el => el.addEventListener('change', saveSettings));
$('#optSubs').addEventListener('change', saveSettings);

$('#btnUpdate').onclick = async () => {
  const st = $('#updState');
  st.textContent = '···';
  const r = await send({ type: 'update' });
  st.textContent = r?.ok ? '✓' : '!';
  $('#hostDetail').textContent = r?.ok ? r.output : 'Update failed: ' + (r?.error || '');
  checkHost();
};

// ---------- what's new: shows once after each update, and from Settings ----------
function renderNews(all) {
  const body = $('#newsBody');
  body.textContent = '';
  for (const rel of (all ? PULL_CHANGELOG : PULL_CHANGELOG.slice(0, 1))) {
    const sec = document.createElement('div'); sec.className = 'news-rel';
    const h = document.createElement('div'); h.className = 'news-v';
    h.innerHTML = '<b></b><span></span>'; h.querySelector('b').textContent = 'v' + rel.v; h.querySelector('span').textContent = rel.date;
    sec.appendChild(h);
    if (rel.title) { const t = document.createElement('p'); t.className = 'news-t'; t.textContent = rel.title; sec.appendChild(t); }
    const ul = document.createElement('ul');
    for (const n of rel.notes) { const li = document.createElement('li'); li.textContent = n; ul.appendChild(li); }
    sec.appendChild(ul); body.appendChild(sec);
  }
  if (!all) {
    const more = document.createElement('button'); more.className = 'txt news-more'; more.textContent = 'Earlier versions ›';
    more.onclick = () => renderNews(true); body.appendChild(more);
  }
}
function openNews(open, all = false) {
  if (open) renderNews(all);
  document.body.classList.toggle('news-open', open);
  $('#news').setAttribute('aria-hidden', String(!open));
}
$('#btnNews').onclick = () => { openSheet(false); openNews(true, true); };
$('#btnNewsDone').onclick = () => openNews(false);
$('#news').addEventListener('click', e => { if (e.target.id === 'news') openNews(false); });
(async () => {
  const ver = chrome.runtime.getManifest().version;
  const { seenVersion } = await chrome.storage.local.get('seenVersion');
  if (seenVersion !== ver) {
    await chrome.storage.local.set({ seenVersion: ver });
    if (seenVersion) setTimeout(() => openNews(true), 350);   // not on a fresh install
  }
})();

// ---------- update banner ----------
let updInfo = null;
function renderUpdate(state) {
  const bar = $('#updBar'), txt = $('#updText'), btn = $('#btnUpd'), dots = $('#updDots');
  const mine = chrome.runtime.getManifest().version;
  const st = state || { phase: 'idle' };
  const v = st.version || (updInfo && updInfo.version);
  const show = st.phase !== 'idle' || (updInfo && updInfo.version !== mine);
  const hb = $('#btnHdrUpd'), has = !!(updInfo && updInfo.version !== mine);
  hb.classList.toggle('has', has);
  hb.title = has ? 'Update to pull. ' + updInfo.version : 'Check for updates';
  bar.classList.toggle('hidden', !show);
  if (!show) return;
  bar.dataset.phase = st.phase;
  btn.style.display = st.phase === 'idle' || st.phase === 'error' ? '' : 'none';
  dots.style.display = st.phase === 'downloading' ? '' : 'none';
  if (st.phase === 'idle') { txt.innerHTML = '<b>pull. ' + v + '</b> is ready'; btn.textContent = 'Update'; }
  else if (st.phase === 'downloading') {
    txt.textContent = 'Downloading ' + v;
    const n = 12, f = Math.round((st.percent || 0) / 100 * n);
    dots.innerHTML = Array.from({ length: n }, (_, i) => `<i class="${i < f ? 'f' : i === f ? 'r' : ''}"></i>`).join('');
  }
  else if (st.phase === 'installing') txt.textContent = 'Installing ' + v + '…';
  else if (st.phase === 'restarting') txt.textContent = 'Restarting pull.…';
  else if (st.phase === 'error') { txt.textContent = 'Update failed: ' + (st.error || ''); btn.textContent = 'Retry'; }
}
$('#btnUpd').onclick = async () => {
  if (Object.values(lastJobs || {}).some(j => j.status === 'running' || j.status === 'queued') &&
      !$('#btnUpd').dataset.sure) { $('#btnUpd').dataset.sure = '1'; $('#updText').textContent = 'Downloads are running — press again to update anyway'; return; }
  renderUpdate({ phase: 'downloading', percent: 0, version: updInfo && updInfo.version });
  const r = await send({ type: 'applyUpdate' });
  if (!r || !r.ok) renderUpdate({ phase: 'error', error: (r && r.error) || 'helper not connected', version: updInfo && updInfo.version });
};
$('#btnCheckUpd').onclick = async () => {
  const st = $('#chkState'); st.textContent = '···';
  const r = await send({ type: 'checkUpdate' });
  if (!r || !r.ok) { st.textContent = '!'; $('#hostDetail').textContent = 'Update check failed: ' + ((r && r.error) || ''); return; }
  const res = r.result || {};
  updInfo = res.update || null;
  st.textContent = res.update ? res.update.version + ' ›' : 'Up to date ✓';
  if (res.update) { openSheet(false); renderUpdate(); }
};
$('#btnHdrUpd').onclick = async () => {
  const hb = $('#btnHdrUpd');
  if (hb.classList.contains('chk')) return;
  if (hb.classList.contains('has')) { $('#btnUpd').click(); return; }
  hb.classList.add('chk'); hb.classList.remove('ok');
  const r = await send({ type: 'checkUpdate' });
  hb.classList.remove('chk');
  const res = (r && r.ok && r.result) || {};
  updInfo = res.update || null;
  renderUpdate();
  if (!r || !r.ok) { hb.title = 'Update check failed: ' + ((r && r.error) || 'helper not connected'); toastHdr(hb.title); return; }
  if (!updInfo) { hb.classList.add('ok'); hb.title = 'Up to date ✓ (' + chrome.runtime.getManifest().version + ')'; toastHdr('Up to date ✓'); setTimeout(() => { hb.classList.remove('ok'); hb.title = 'Check for updates'; }, 2400); }
};
function toastHdr(t) {
  const st = $('#chkState'); if (st) st.textContent = t;
  const b = $('#updBar'), txt = $('#updText');
  if (!b.classList.contains('hidden')) return;
  b.classList.remove('hidden'); b.dataset.phase = 'note'; $('#btnUpd').style.display = 'none'; $('#updDots').style.display = 'none';
  txt.textContent = t;
  clearTimeout(toastHdr.t); toastHdr.t = setTimeout(() => { if (b.dataset.phase === 'note') b.classList.add('hidden'); }, 2200);
}
chrome.runtime.onMessage.addListener(m => { if (m.type === 'updateState') renderUpdate(m.state); });
(async () => {
  const r = await send({ type: 'getUpdate' });
  if (r && r.ok) { updInfo = r.update; renderUpdate(r.state); }
})();
