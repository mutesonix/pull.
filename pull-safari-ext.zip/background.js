// pull. — background service worker · by SUNN. (Trithaset Chaimongkol)
// Talks to the native host (com.sunn.pull), which runs yt-dlp / ffmpeg on this machine.
if (typeof Sites === 'undefined' && typeof importScripts === 'function') importScripts('sites.js');

const HOST = 'com.sunn.pull';
const DEFAULTS = {
  quality: 'best',        // best | 2160 | 1440 | 1080 | 720 | 480 | 360 | audio
  container: 'mp4',       // mp4 | mkv
  subtitles: false,
  subLangs: 'en,th',
  cookies: 'none',        // YouTube login: none | self (this browser) | firefox
  fbLogin: true,          // Facebook & TikTok: use this browser's login (most FB videos need it)
  outDir: '',             // empty = ~/Downloads/pull
  notify: true,
  h264: true,             // prefer H.264/AAC for editing apps
  prefetch: true,         // read formats while browsing so the popup is instant
  convert: true,          // 2K/4K → H.264 MP4 after download
  keepOriginal: false,    // keep the VP9/AV1 file after converting
  capFmt: 'png',          // png | jpg
  clipCapture: true,      // copy captures to the clipboard
  inPlayer: true,         // pull. + capture buttons inside the video player
  autoUpdate: true,       // check the Drive folder for a newer pull.
  board: true,            // put every capture on today's reference board
  loopFmt: 'gif',         // gif | webp
  loopWidth: 640,         // loop width in px
  audioFmt: 'mp3',        // mp3 | wav (48 kHz PCM)
  project: '',            // when set, everything goes in <Save to>/<project>
};

// Safari has no Chromium-style native messaging: there the helper runs as a local bridge (pull. Setup installs it)
const BRIDGE = !!(chrome.runtime.getManifest().browser_specific_settings || {}).safari || typeof chrome.runtime.connectNative !== 'function';
const BRIDGE_URL = 'http://127.0.0.1:17311';
const BRIDGE_HDR = { 'X-Pull-Client': 'pull-ext' };
const BRIDGE_DOWN = 'pull. helper isn\'t running — open pull. Setup on this Mac';

let port = null;
let hostInfo = null;
let jobs = {};             // id -> job  { kind: download | capture | convert }
const pending = new Map();
let reqSeq = 0;

// ---------- native port ----------
function getPort() {
  if (port) return port;
  port = chrome.runtime.connectNative(HOST);
  port.onMessage.addListener(onHostMessage);
  port.onDisconnect.addListener(() => {
    const err = chrome.runtime.lastError?.message || 'Host disconnected';
    port = null;
    hostInfo = null;
    for (const [, p] of pending) p.reject(new Error(err));
    pending.clear();
    for (const j of Object.values(jobs)) {
      if (j.status === 'running' || j.status === 'queued') Object.assign(j, { status: 'error', error: 'Host stopped: ' + err });
    }
    broadcast();
  });
  return port;
}

function call(cmd, payload = {}) {
  return new Promise((resolve, reject) => {
    const reqId = 'r' + (++reqSeq);
    pending.set(reqId, { resolve, reject });
    if (BRIDGE) {
      bridgeSend({ cmd, reqId, ...payload }).catch(e => { pending.delete(reqId); reject(e); });
      return;
    }
    try { getPort().postMessage({ cmd, reqId, ...payload }); }
    catch (e) { pending.delete(reqId); reject(e); }
  });
}

// ---------- local bridge (Safari) ----------
let bridgeAfter = null;   // event cursor
let polling = false;

async function bridgeFetch(path, init = {}) {
  let r;
  try { r = await fetch(BRIDGE_URL + path, { ...init, headers: { ...BRIDGE_HDR, ...(init.headers || {}) } }); }
  catch { throw new Error(BRIDGE_DOWN); }
  if (!r.ok) throw new Error('bridge HTTP ' + r.status);
  return r;
}

async function bridgeSend(msg) {
  if (bridgeAfter === null) bridgeAfter = (await (await bridgeFetch('/v1/hello')).json()).seq; // cursor first, so no reply is missed
  await bridgeFetch('/v1/send', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(msg) });
  pollBridge();
}

const busyJobs = () => Object.values(jobs).some(j => j.status === 'running' || j.status === 'queued') ||
  (typeof updateState !== 'undefined' && (updateState.phase === 'downloading' || updateState.phase === 'installing'));

async function pollBridge() {
  if (polling) return;
  polling = true;
  let misses = 0;
  try {
    // keep listening while anything is in flight; stop when idle so Safari can suspend us
    while (pending.size || busyJobs()) {
      let d;
      try {
        if (bridgeAfter === null) bridgeAfter = (await (await bridgeFetch('/v1/hello')).json()).seq;
        d = await (await bridgeFetch('/v1/events?after=' + bridgeAfter)).json();
        misses = 0;
      } catch (e) {
        // a dropped poll (Safari waking us up, Wi-Fi switch, Mac asleep) isn't a failed download:
        // the helper keeps working, so retry for a while before giving up
        if (++misses > 8) throw e;
        await new Promise(r => setTimeout(r, Math.min(8000, 500 * 2 ** misses)));
        continue;
      }
      if (d.events.length && d.events[0].seq <= bridgeAfter) bridgeAfter = 0; // helper restarted
      for (const e of d.events) { bridgeAfter = Math.max(bridgeAfter, e.seq); onHostMessage(e.msg); }
      bridgeAfter = Math.max(bridgeAfter, d.seq);
    }
  } catch (e) {
    for (const [, p] of pending) p.reject(e);
    pending.clear();
    for (const j of Object.values(jobs)) if (j.status === 'running' || j.status === 'queued') Object.assign(j, { status: 'error', error: e.message });
    hostInfo = null;
    bridgeAfter = null;
    broadcast();
  } finally {
    polling = false;
  }
}

// Safari suspends an idle extension background and throws away its memory — including the job list.
// Keep the list in storage and, on wake-up, ask the helper how each running job ended up.
let saveTimer = 0;
function saveJobs() {
  if (!BRIDGE) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const keep = {};
    for (const [k, j] of Object.entries(jobs)) if (Date.now() - (j.created || 0) < 24 * 3600e3) keep[k] = j;
    chrome.storage.local.set({ bridgeJobs: keep }).catch(() => {});
  }, 400);
}

async function restoreJobs() {
  if (!BRIDGE) return;
  try {
    const { bridgeJobs } = await chrome.storage.local.get('bridgeJobs');
    if (!bridgeJobs) return;
    for (const [k, j] of Object.entries(bridgeJobs)) if (!jobs[k]) jobs[k] = j;
    const live = Object.values(jobs).filter(j => j.status === 'running' || j.status === 'queued');
    if (!live.length) { broadcast(); return; }
    const r = await call('jobs');
    for (const j of live) {
      const last = r.jobs && r.jobs[j.id];
      if (last) onHostMessage(last);
      else if (Date.now() - (j.created || 0) > 60000) Object.assign(j, { status: 'error', error: 'pull. helper restarted — press Retry' });
    }
    broadcast();
    pollBridge();
  } catch {}
}
const restored = restoreJobs();

function onHostMessage(msg) {
  if (msg.reqId && pending.has(msg.reqId)) {
    const p = pending.get(msg.reqId);
    pending.delete(msg.reqId);
    msg.ok ? p.resolve(msg) : p.reject(new Error(msg.error || 'Host error'));
    return;
  }
  if (msg.id === '__update') { onUpdateEvent(msg); return; }
  const j = jobs[msg.id];
  if (!j) return;
  switch (msg.type) {
    case 'progress':
      Object.assign(j, { status: 'running', percent: msg.percent, speed: msg.speed, eta: msg.eta, phase: msg.phase || j.phase });
      break;
    case 'phase':
      Object.assign(j, { status: 'running', phase: msg.phase, percent: msg.phase === 'converting' ? 0 : j.percent });
      break;
    case 'picked':
      Object.assign(j, { title: msg.title, src: msg.file, status: 'running', phase: 'reading' });
      break;
    case 'done':
      Object.assign(j, { status: 'done', percent: 100, file: msg.file, size: msg.size, width: msg.width, height: msg.height, copied: msg.copied, note: msg.note, count: msg.count, sheet: msg.sheet, board: msg.board });
      if (j.kind === 'capture') notify(j.crop ? 'Snipped' : 'Captured', `${msg.width}×${msg.height}${msg.copied ? ' · copied to clipboard' : ''}\n${j.title}`);
      else if (j.kind === 'convert') notify('Converted', j.title);
      else if (j.kind === 'stills') notify('Stills ready', `${msg.count} frames · ${j.title}`);
      else if (j.kind === 'loop') notify(j.format.toUpperCase() + ' ready', j.title);
      else if (j.kind === 'thumb') notify('Cover saved', `${msg.width || ''}${msg.width ? '×' + msg.height + ' · ' : ''}${j.title}`);
      else notify('Downloaded', j.title || msg.file);
      break;
    case 'error':
      if (msg.dismiss) { delete jobs[msg.id]; break; }
      if (!msg.cancelled && j.kind === 'download' && j.site === 'tiktok' && !j.triedYtdlp && j.via === 'browser') { ytdlpDownload(j, msg.error); return; }
      if (!msg.cancelled && j.kind === 'download' && j.site === 'tiktok' && !j.triedBrowser && j.via === 'yt-dlp') { browserDownload(j, msg.error).then(ok => { if (!ok) finishError(j, msg.error); }); return; }
      if (j.kind === 'capture' && msg.fallback && j.via === 'browser' && !j.triedYtdlp) { j.triedYtdlp = true; j.via = 'yt-dlp'; captureViaYtdlp(j); return; }
      if (j.kind === 'capture' && msg.fallback && !j.triedFallback) { captureFallback(j, msg.error); return; }
      Object.assign(j, { status: msg.cancelled ? 'cancelled' : 'error', error: msg.error, file: msg.file || j.file });
      if (!msg.cancelled) notify({ capture: j.crop ? 'Snip failed' : 'Capture failed', convert: 'Convert failed', loop: 'Loop failed', thumb: 'Cover failed' }[j.kind] || 'Download failed',
        (j.title ? j.title + ' — ' : '') + shortErr(msg.error));
      break;
  }
  broadcast();
}

function finishError(j, error) {
  Object.assign(j, { status: 'error', error });
  notify('Download failed', (j.title ? j.title + ' — ' : '') + shortErr(error));
  broadcast();
}

function shortErr(e = '') {
  const line = String(e).split('\n').filter(Boolean).pop() || e;
  return line.length > 140 ? line.slice(0, 140) + '…' : line;
}

async function notify(title, message) {
  if (!chrome.notifications) return; // Safari
  const s = await getSettings();
  if (!s.notify) return;
  chrome.notifications.create({ type: 'basic', iconUrl: 'icons/128.png', title: 'pull. · ' + title, message: message || '' });
}

const pushed = new Map();   // job id -> last state sent to the in-player toast
function pushToPlayers() {
  for (const j of Object.values(jobs)) {
    if (j.pushTab == null) continue;
    const pct = typeof j.percent === 'number' ? Math.floor(j.percent / 5) * 5 : null;
    const sig = j.status + '|' + pct + '|' + (j.phase || '');
    if (pushed.get(j.id) === sig) continue;
    pushed.set(j.id, sig);
    chrome.tabs.sendMessage(j.pushTab, { type: 'pullJob', job: { id: j.id, kind: j.kind, status: j.status, percent: j.percent, phase: j.phase || '', copied: !!j.copied, format: j.format || '' } },
      { frameId: j.pushFrame || 0 }).catch(() => {});
  }
  if (pushed.size > 200) for (const k of pushed.keys()) if (!jobs[k]) pushed.delete(k);
}
function broadcast() {
  saveJobs();
  chrome.runtime.sendMessage({ type: 'state', jobs }).catch(() => {});
  pushToPlayers();
  const active = Object.values(jobs).filter(j => j.status === 'running' || j.status === 'queued').length;
  chrome.action.setBadgeBackgroundColor?.({ color: '#D71921' });
  chrome.action.setBadgeText({ text: active ? String(active) : '' });
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...(settings || {}) };
  if (['brave', 'chrome', 'edge'].includes(s.cookies)) s.cookies = 'self';
  return s;
}

// ---------- logins ----------
// Export this browser's cookies for a site as a Netscape cookies.txt that only the local yt-dlp sees
async function cookieText(domains) {
  if (!chrome.cookies) return '';
  const all = [];
  for (const domain of domains) all.push(...await chrome.cookies.getAll({ domain }));
  if (!all.length) return '';
  const lines = ['# Netscape HTTP Cookie File'];
  for (const c of all) {
    const dom = (c.httpOnly ? '#HttpOnly_' : '') + (c.hostOnly ? c.domain : (c.domain.startsWith('.') ? c.domain : '.' + c.domain));
    lines.push([dom, c.hostOnly ? 'FALSE' : 'TRUE', c.path, c.secure ? 'TRUE' : 'FALSE',
      c.session ? 0 : Math.floor(c.expirationDate || 0), c.name, c.value].join('\t'));
  }
  return lines.join('\n') + '\n';
}

async function withLogin(opts, url) {
  const site = (Sites.parse(url) || {}).site;
  if (site === 'vimeo') {
    const base = { ...opts, site, cookies: 'none' };
    return opts.fbLogin === false ? base : { ...base, cookieText: await cookieText(['vimeo.com']) };
  }
  if (site === 'pinterest') return { ...opts, site, cookies: 'none' };   // public pins need no login
  if (site === 'instagram') {   // most reels need the browser's Instagram login
    const base = { ...opts, site, cookies: 'none' };
    return opts.fbLogin === false ? base : { ...base, cookieText: await cookieText(['instagram.com']) };
  }
  if (site === 'facebook' || site === 'tiktok') {
    const base = { ...opts, site, cookies: 'none' };
    // TikTok often serves its top resolution only as H.265 → take the best, convert to H.264 if needed
    if (site === 'tiktok' && opts.h264 !== false) base.autoH264 = true;
    if (opts.fbLogin === false) return base;
    return { ...base, cookieText: await cookieText([site === 'facebook' ? 'facebook.com' : 'tiktok.com']) };
  }
  if (site === 'youtube' && opts.cookies === 'self')
    return { ...opts, cookies: 'none', cookieText: await cookieText(['youtube.com', 'google.com']) };
  if (opts.cookies === 'self') return { ...opts, cookies: 'none' };
  return opts;
}

// ---------- fast detection ----------
// YouTube: oEmbed gives title/channel/thumbnail in ~200 ms. Formats (yt-dlp -J) are prefetched
// as soon as a tab lands on a video, so they're usually ready before the popup opens.
const fmtCache = new Map();
const metaCache = new Map();
const TTL = 30 * 60 * 1000;

function prefetchFormats(url, force = false, referer = '') {
  const t = Sites.parseAny(url);
  if (t && t.needsResolve) return resolveUrl(url).then(u => u === url ? fetchInfo(t, force, referer) : prefetchFormats(u, force, referer));
  return fetchInfo(t, force, referer);
}

function fetchInfo(t, force, referer = '') {
  if (!t || t.playlistOnly) return Promise.reject(new Error('not a video'));
  const hit = fmtCache.get(t.key);
  if (hit && !force && ((!hit.done) || (Date.now() - hit.t < TTL && !hit.error))) return hit.promise;
  const entry = { t: Date.now(), done: false };
  entry.promise = (async () => {
    if (t.site === 'tiktok' && t.id) {
      const item = await tiktokItem(t.id, force).catch(() => null);
      if (item && item.formats.length) return tiktokInfo(item);
    }
    const opts = { ...(await getSettings()), referer };
    const r = await call('info', { url: t.url, options: await withLogin(opts, t.url) });
    return r.info;
  })();
  entry.promise.then(info => { entry.info = info; entry.done = true; }, err => { entry.error = err.message; entry.done = true; });
  fmtCache.set(t.key, entry);
  if (fmtCache.size > 60) fmtCache.delete(fmtCache.keys().next().value);
  return entry.promise;
}

async function getMeta(url) {
  const t = Sites.parse(url);
  if (!t || !t.id || !['youtube', 'tiktok', 'vimeo'].includes(t.site)) return null; // Facebook has no public oEmbed; formats carry the title
  if (metaCache.has(t.key)) return metaCache.get(t.key);
  const oembed = t.site === 'youtube'
    ? 'https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent('https://www.youtube.com/watch?v=' + t.id)
    : t.site === 'vimeo'
      ? 'https://vimeo.com/api/oembed.json?width=640&url=' + encodeURIComponent(t.url)
      : 'https://www.tiktok.com/oembed?url=' + encodeURIComponent('https://www.tiktok.com/@_/video/' + t.id);
  const r = await fetch(oembed);
  if (!r.ok) throw new Error('oEmbed ' + r.status);
  const j = await r.json();
  const meta = { title: j.title, uploader: j.author_name, thumbnail: t.thumb || j.thumbnail_url };
  metaCache.set(t.key, meta);
  return meta;
}

const navTimers = {};
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (!change.url || !Sites.parse(change.url)) return;
  clearTimeout(navTimers[tabId]);
  navTimers[tabId] = setTimeout(async () => {
    if ((await getSettings()).prefetch === false) return;
    getMeta(change.url).catch(() => {});
    prefetchFormats(change.url).catch(() => {});
  }, 400);
});

// Facebook share / fb.watch and TikTok vm. / vt. links only redirect to the real video — follow them (with the session)
const resolved = new Map();
async function resolveUrl(url) {
  const t = Sites.parse(url);
  if (!t || !t.needsResolve) return url;
  if (resolved.has(url)) return resolved.get(url);
  try {
    const r = await fetch(url, { redirect: 'follow', credentials: 'include' });
    const real = Sites.parse(r.url);
    const out = real && !real.needsResolve ? real.url : url;
    resolved.set(url, out);
    return out;
  } catch { return url; }
}

// ---------- TikTok browser mode ----------
// Read the post inside a tiktok.com tab with the user's own session (what TikTok's player does),
// then download the watermark-free stream directly. Gets TikTok Shop / commerce posts yt-dlp is blocked on.
const ttItems = new Map(); // id -> { t, item }

async function waitTab(tabId, ms = 15000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) throw new Error('tab closed');
    if (tab.status === 'complete') return;
    await new Promise(r => setTimeout(r, 200));
  }
}

async function withTikTokTab(fn) {
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = active && /^https:\/\/www\.tiktok\.com\//.test(active.url || '') ? active : null;
  if (!tab) [tab] = await chrome.tabs.query({ url: 'https://www.tiktok.com/*' });
  let temp = null;
  if (!tab) {
    temp = await chrome.tabs.create({ url: 'https://www.tiktok.com/robots.txt', active: false });
    await waitTab(temp.id);
    tab = temp;
  }
  try { return await fn(tab.id); }
  finally { if (temp) chrome.tabs.remove(temp.id).catch(() => {}); }
}

async function tiktokItem(id, force = false) {
  const hit = ttItems.get(id);
  if (hit && !force && Date.now() - hit.t < 15 * 60 * 1000) return hit.item;
  const item = await withTikTokTab(async tabId => {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: pullTikTokItem, args: [String(id)] });
    return r && r.result;
  });
  if (!item) throw new Error('could not read the TikTok page');
  if (item.formats.length) ttItems.set(id, { t: Date.now(), item });
  if (ttItems.size > 40) ttItems.delete(ttItems.keys().next().value);
  return item;
}

const shortSide = f => Math.min(f.w || 0, f.h || 0) || f.h || f.w || 0;

// best first: requested size (short side, like "1080p"), then H.264 when it's a tie, then bitrate; player copy last
function rankTikTok(formats, quality, preferH264) {
  const q = /^\d+$/.test(quality || '') ? +quality : 0;
  const seen = new Set();
  const list = formats.filter(f => f.url && !seen.has(f.url) && seen.add(f.url));
  const fit = f => { const s = shortSide(f); return q ? (s <= q + 10 ? 1e6 + s : 1e6 - s) : s; };
  return list.sort((a, b) =>
    (fit(b) - fit(a)) ||
    ((preferH264 ? (b.codec === 'h264') - (a.codec === 'h264') : 0)) ||
    ((a.play || 0) - (b.play || 0)) ||
    ((b.br || 0) - (a.br || 0)));
}

function tiktokInfo(item) {
  const heights = [...new Set(item.formats.map(shortSide).filter(Boolean))].sort((a, b) => a - b);
  const best = item.formats.reduce((m, f) => ((f.w || 0) * (f.h || 0) > (m.w || 0) * (m.h || 0) ? f : m), {});
  return { title: item.title, uploader: item.uploader, duration: item.duration, thumbnail: item.cover,
           heights, maxW: best.w || 0, maxH: best.h || 0, browser: true };
}

async function tiktokCookie() {
  if (!chrome.cookies) return '';
  const all = await chrome.cookies.getAll({ domain: 'tiktok.com' });
  return all.map(c => c.name + '=' + c.value).join('; ');
}

async function browserDownload(j, why) {
  j.triedBrowser = true;
  j.via = 'browser';
  Object.assign(j, { status: 'running', phase: 'reading page', percent: null, error: null });
  broadcast();
  try {
    const t = Sites.parse(j.url);
    const item = await tiktokItem(t.id, !!why);
    if (!item.formats.length) throw new Error(item.status ? 'TikTok status ' + item.status : 'no stream on the page');
    if (item.title && (!j.title || j.title === j.url)) j.title = item.title;
    const opts = { ...j.opts, autoH264: j.opts.h264 !== false };
    const urls = rankTikTok(item.formats, j.opts.quality === 'audio' ? '' : j.opts.quality, j.opts.h264 !== false).map(f => f.url).slice(0, 12);
    await call('fetchDirect', {
      id: j.id, urls, title: j.title, vid: t.id, options: opts,
      headers: { 'Referer': 'https://www.tiktok.com/', 'User-Agent': item.ua || navigator.userAgent, 'Accept': '*/*' },
      cookie: await tiktokCookie(), domain: 'tiktok.com',
    });
    return true;
  } catch (e) {
    j.browserError = e.message;
    return false;
  }
}

async function ytdlpDownload(j, why) {
  j.triedYtdlp = true;
  j.via = 'yt-dlp';
  Object.assign(j, { status: 'running', phase: 'starting', percent: null, error: null });
  broadcast();
  try { await call('download', { id: j.id, url: j.url, options: await withLogin(j.opts, j.url) }); }
  catch (e) { finishError(j, (why ? why + '\n' : '') + e.message); }
}

// ---------- jobs ----------
const newId = () => 'j' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

async function startDownload({ url, title, thumb, options }) {
  url = await resolveUrl(url);
  const opts = { ...(await getSettings()), ...(options || {}) };
  const t = Sites.parse(url) || {};
  const id = newId();
  const j = jobs[id] = { id, kind: 'download', url, site: t.site, title: title || url, thumb, quality: opts.quality, convert: !!opts.convert, section: opts.section || null,
                         opts, status: 'queued', percent: 0, created: Date.now() };
  broadcast();
  // TikTok: the browser's own session first (works for Shop posts), yt-dlp as backup
  if (t.site === 'tiktok' && t.id && !opts.playlist && await browserDownload(j)) return id;
  j.via = 'yt-dlp';
  j.triedYtdlp = true;
  try { await call('download', { id, url, options: await withLogin(opts, url) }); }
  catch (e) { finishError(j, e.message); }
  return id;
}

async function startConvert(path) {
  const id = newId();
  jobs[id] = { id, kind: 'convert', title: path ? path.split(/[\\/]/).pop() : 'Choose a file…', status: 'queued', phase: path ? 'reading' : 'picking', created: Date.now() };
  broadcast();
  try { await call('convert', { id, path: path || '', options: await getSettings() }); }
  catch (e) { Object.assign(jobs[id], { status: 'error', error: e.message }); broadcast(); }
  return id;
}

// Capture the frame at `time` from the highest-resolution stream of the video.
// crop {x, y, w, h} (fractions of the frame) = a snip: cut from the full-res frame, never from the player picture.
async function startCapture({ tabId, url, title, time, referer, pushTab, pushFrame, crop }) {
  url = await resolveUrl(url);
  url = (Sites.parse(url) || {}).url || url;   // same key the formats prefetch used, so its stream URL is reused
  const t = Sites.parse(url) || {};
  const id = newId();
  crop = crop && crop.w > 0 && crop.h > 0 ? { x: +crop.x, y: +crop.y, w: +crop.w, h: +crop.h } : undefined;
  const j = jobs[id] = { id, kind: 'capture', tabId, pushTab, pushFrame, url, site: t.site, referer, title: title || url, time, crop, status: 'queued', phase: 'finding source', created: Date.now() };
  broadcast();
  if (t.site === 'tiktok' && t.id) {
    try {
      const item = await tiktokItem(t.id);
      const best = rankTikTok(item.formats, '', false)[0];
      if (best) {
        j.via = 'browser';
        await call('capture', { id, url, time, crop, title: j.title, options: await getSettings(),
          direct: { url: best.url, w: best.w, h: best.h, cookie: await tiktokCookie(), domain: 'tiktok.com',
                    headers: { 'Referer': 'https://www.tiktok.com/', 'User-Agent': item.ua || navigator.userAgent } } });
        return id;
      }
    } catch {}
  }
  j.via = 'yt-dlp';
  await captureViaYtdlp(j);
  return id;
}

// Stills: frames across the whole clip every N seconds, plus a contact sheet
async function startStills({ url, title, interval, duration, mode }) {
  url = await resolveUrl(url);
  url = (Sites.parse(url) || {}).url || url;
  const t = Sites.parse(url) || {};
  const id = newId();
  const j = jobs[id] = { id, kind: 'stills', url, site: t.site, title: title || url, interval, mode, status: 'queued', phase: 'finding source', created: Date.now() };
  broadcast();
  const s = await getSettings();
  let direct;
  if (t.site === 'tiktok' && t.id) {
    try {
      const item = await tiktokItem(t.id);
      const best = rankTikTok(item.formats, '', false)[0];
      if (best) direct = { url: best.url, w: best.w, h: best.h, cookie: await tiktokCookie(), domain: 'tiktok.com',
                           headers: { 'Referer': 'https://www.tiktok.com/', 'User-Agent': item.ua || navigator.userAgent } };
      if (!duration && item.duration) duration = item.duration;
    } catch {}
  }
  if (!duration) duration = fmtCache.get(t.key)?.info?.duration || 0;
  try { await call('stills', { id, url, title: j.title, interval, mode, duration, direct, options: await withLogin(s, url) }); }
  catch (e) { finishError(j, e.message); }
  return id;
}

// Loop: IN → OUT as a GIF / animated WebP
async function startLoop({ url, title, start, end, pushTab, pushFrame }) {
  url = await resolveUrl(url);
  url = (Sites.parse(url) || {}).url || url;
  const t = Sites.parse(url) || {};
  const s = await getSettings();
  const id = newId();
  const j = jobs[id] = { id, kind: 'loop', url, site: t.site, title: title || url, format: s.loopFmt === 'webp' ? 'webp' : 'gif', section: { start, end },
                         pushTab, pushFrame, status: 'queued', phase: 'finding source', created: Date.now() };
  broadcast();
  try { await call('loop', { id, url, title: j.title, start, end, format: j.format, width: +s.loopWidth || 640, options: await withLogin(s, url) }); }
  catch (e) { finishError(j, e.message); }
  return id;
}

// Cover: the video's thumbnail at the highest resolution the site has
async function startThumb({ url, title }) {
  url = await resolveUrl(url);
  url = (Sites.parse(url) || {}).url || url;
  const t = Sites.parse(url) || {};
  const id = newId();
  const j = jobs[id] = { id, kind: 'thumb', url, site: t.site, title: title || url, status: 'queued', phase: 'finding source', created: Date.now() };
  broadcast();
  try { await call('thumb', { id, url, title: j.title, options: await withLogin(await getSettings(), url) }); }
  catch (e) { finishError(j, e.message); }
  return id;
}

async function captureViaYtdlp(j) {
  try {
    const s = { ...(await getSettings()), referer: j.referer || '' };
    await call('capture', { id: j.id, url: j.url, time: j.time, crop: j.crop, title: j.title || 'capture', options: await withLogin(s, j.url) });
  } catch (e) { if (j.crop) finishError(j, e.message); else await captureFallback(j, e.message); }
}

// When the full-res stream can't be fetched: grab what the page is showing (player quality)
async function captureFallback(j, why) {
  j.triedFallback = true;
  j.phase = 'grabbing from page';
  broadcast();
  try {
    const s = await getSettings();
    // The full-res try can take a few seconds; only grab if the tab still shows the same video, or the frame would be from another one
    const tab = await chrome.tabs.get(j.tabId).catch(() => null);
    const now = tab && Sites.parse(tab.url), was = Sites.parse(j.url);
    if (was && now && was.key !== now.key) throw new Error('you left the video before pull. could grab it — capture again on that page');
    const [res] = await chrome.scripting.executeScript({ target: { tabId: j.tabId }, func: pullPageVideo, args: ['grab', s.capFmt] });
    const g = res && res.result;
    if (!g || g.error || !g.data) throw new Error(g && g.error ? 'page blocked the grab' : 'no video on the page');
    j.lowRes = true;
    await call('saveImage', { id: j.id, data: g.data, w: g.w, h: g.h, time: j.time ?? g.t, title: j.title, url: j.url, options: s });
  } catch (e) {
    Object.assign(j, { status: 'error', error: shortErr(why) + '\n' + e.message });
    broadcast();
  }
}

async function videoState(tabId) {
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: pullPageVideo, args: ['state'] });
    return res && res.result;
  } catch { return null; }
}

async function captureActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  const st = await videoState(tab.id);
  if (!st) { notify('Nothing to capture', 'No video on this page.'); return; }
  const t = Sites.parse(tab.url) || (st.link && Sites.parse(st.link));
  if (!t) { notify('Nothing to capture', 'Open the video itself (on Facebook click its timestamp).'); return; }
  const cached = fmtCache.get(t.key);
  const title = cached?.info?.title || metaCache.get(t.key)?.title || (tab.title || '').replace(/^\(\d+\)\s*/, '').replace(/ (?:[-|] |on )(YouTube|Facebook|TikTok|Vimeo|Instagram|Pinterest)$/, '');
  const id = await startCapture({ tabId: tab.id, url: t.url, title, time: st.t });
  chrome.tabs.sendMessage(tab.id, { type: 'pullKey', kind: 'capture', id }, { frameId: 0 }).catch(() => {});
  if (jobs[id]) Object.assign(jobs[id], { pushTab: tab.id, pushFrame: 0 });
}

// Alt+Shift+X: draw a box over the video (like Snipping Tool); the page script measures it and sends 'capture' with crop
async function snipActiveTab(tabId) {
  if (tabId == null) { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = tab?.id; }
  if (tabId == null) return false;
  try { await chrome.tabs.sendMessage(tabId, { type: 'pullSnip' }, { frameId: 0 }); return true; }
  catch { notify('Nothing to snip', 'Open a YouTube, Facebook, Instagram, TikTok or Vimeo video (reload the page once after updating pull.).'); return false; }
}

// Alt+Shift+G: a loop of the trim range if one is set on this video, otherwise the 5 s from the playhead
async function loopActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  const tell = m => chrome.tabs.sendMessage(tab.id, { type: 'pullKey', kind: 'loop', ...m }, { frameId: 0 }).catch(() => {});
  const st = await videoState(tab.id);
  if (!st) { notify('Nothing to loop', 'No video on this page.'); return; }
  const t = Sites.parse(tab.url) || (st.link && Sites.parse(st.link));
  if (!t) { tell({ error: 'Open the video itself first' }); return; }
  let start = st.t || 0, end = start + 5;
  try {
    const { trim } = await chrome.storage.local.get('trim');
    if (trim && trim.key === t.key && trim.end > trim.start && Date.now() - (trim.at || 0) < 12 * 3600e3) ({ start, end } = trim);
  } catch {}
  if (st.dur && isFinite(st.dur)) { end = Math.min(end, st.dur); if (end - start < .5) start = Math.max(0, end - 5); }
  if (end - start > 30) { tell({ error: 'Loops are up to 30 s — tighten IN / OUT' }); return; }
  const cached = fmtCache.get(t.key);
  const title = cached?.info?.title || metaCache.get(t.key)?.title || (tab.title || '').replace(/^\(\d+\)\s*/, '').replace(/ (?:[-|] |on )(YouTube|Facebook|TikTok|Vimeo|Instagram|Pinterest)$/, '');
  const id = await startLoop({ url: t.url, title, start: +start.toFixed(3), end: +end.toFixed(3), pushTab: tab.id, pushFrame: 0 });
  tell({ id, format: jobs[id]?.format });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case 'ping': {
          if (!hostInfo) hostInfo = await call('ping');
          sendResponse({ ok: true, host: hostInfo });
          break;
        }
        case 'resolve': sendResponse({ ok: true, url: await resolveUrl(msg.url) }); break;
        case 'meta': sendResponse({ ok: true, meta: await getMeta(msg.url) }); break;
        case 'formats': sendResponse({ ok: true, info: await prefetchFormats(msg.url, msg.force, msg.referer || '') }); break;
        case 'download': {
          const id = await startDownload(msg);
          if (msg.fromPlayer && sender.tab && jobs[id]) Object.assign(jobs[id], { pushTab: sender.tab.id, pushFrame: sender.frameId || 0 });
          sendResponse({ ok: true, id }); break;
        }
        case 'loop': sendResponse({ ok: true, id: await startLoop({ ...msg, pushTab: msg.fromPlayer ? sender.tab?.id : undefined, pushFrame: sender.frameId || 0 }) }); break;
        case 'thumb': sendResponse({ ok: true, id: await startThumb(msg) }); break;
        case 'open': await call('open', { path: msg.path }); sendResponse({ ok: true }); break;
        case 'openBoard': await chrome.tabs.create({ url: chrome.runtime.getURL('board.html') + (msg.day ? '#day=' + msg.day : '') }); sendResponse({ ok: true }); break;
        case 'boardList': { const r = await call('boardList', { options: await getSettings() }); sendResponse({ ok: true, items: r.items || [], library: r.library || null, project: r.project || '', dir: r.dir || '' }); } break;
        case 'boardThumb': { const r = await call('boardThumb', { key: msg.key, options: await getSettings() }); sendResponse({ ok: true, thumb: r.thumb || '' }); } break;
        case 'boardSave': await call('boardSave', { library: msg.library, options: await getSettings() }); sendResponse({ ok: true }); break;
        case 'boardExport': { const r = await call('boardExport', { name: msg.name, sections: msg.sections, notes: msg.notes || {}, open: true, options: await getSettings() }); sendResponse({ ok: true, path: r.path, count: r.count }); } break;
        case 'stills': sendResponse({ ok: true, id: await startStills({ ...msg, tabId: msg.tabId ?? sender.tab?.id }) }); break;
        case 'capture': {
          const id = await startCapture({ ...msg, tabId: msg.tabId ?? sender.tab?.id, pushTab: msg.fromPlayer ? sender.tab?.id : undefined, pushFrame: sender.frameId || 0 });
          sendResponse({ ok: true, id }); break;
        }
        case 'snipStart': sendResponse({ ok: await snipActiveTab(msg.tabId) }); break;
        case 'convert': sendResponse({ ok: true, id: await startConvert(msg.path) }); break;
        case 'clip': await call('clip', { path: msg.path }); sendResponse({ ok: true }); break;
        case 'cancel': await call('cancel', { id: msg.id }); sendResponse({ ok: true }); break;
        case 'reveal': await call('reveal', { path: msg.path }); sendResponse({ ok: true }); break;
        case 'openDir': { const s = await getSettings(); await call('reveal', { path: s.outDir || '', project: s.project || '', dir: true }); } sendResponse({ ok: true }); break;
        case 'update': {
          const r = await call('update');
          hostInfo = null;
          sendResponse({ ok: true, output: r.output });
          break;
        }
        case 'clear':
          for (const [k, j] of Object.entries(jobs)) if (!['running', 'queued'].includes(j.status)) delete jobs[k];
          broadcast(); sendResponse({ ok: true }); break;
        case 'getState': await restored; sendResponse({ ok: true, jobs }); break;
        case 'checkUpdate': sendResponse({ ok: true, result: await checkUpdate(true) }); break;
        case 'applyUpdate': await applyUpdate(); sendResponse({ ok: true }); break;
        case 'build': sendResponse({ ok: true, build: BG_BUILD, version: chrome.runtime.getManifest().version }); break;
        case 'getUpdate': sendResponse({ ok: true, state: updateState, update: (await chrome.storage.local.get('update')).update || null }); break;
        default: sendResponse({ ok: false, error: 'unknown message' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
});

// ---------- stale-code guard ----------
// The installer replaces the files on disk, but the browser keeps running the old code until the
// extension reloads. If the helper on disk is newer than the code running here, reload once.
const BG_BUILD = '2.5.0';
async function reloadIfStale(hostVersion) {
  if (!hostVersion || !verGt(hostVersion, chrome.runtime.getManifest().version)) return;
  const { selfReloadAt } = await chrome.storage.local.get('selfReloadAt');
  if (selfReloadAt && Date.now() - selfReloadAt < 60000) return;   // tried a moment ago: don't loop
  await chrome.storage.local.set({ selfReloadAt: Date.now() });
  chrome.runtime.reload();
}
setTimeout(() => call('ping').then(r => { hostInfo = r; reloadIfStale(r.host); }).catch(() => {}), 2500);

// ---------- shortcut ----------
chrome.commands?.onCommand.addListener(cmd => { if (cmd === 'capture-frame') captureActiveTab(); else if (cmd === 'snip-frame') snipActiveTab(); else if (cmd === 'make-gif') loopActiveTab(); });

// ---------- install / menus ----------
// handshake: lets the installer see that the extension is loaded and connected
function handshake() { call('ping').then(r => { hostInfo = r; }).catch(() => {}); }
chrome.runtime.onStartup.addListener(handshake);

const PAGES = ['https://www.youtube.com/*', 'https://m.youtube.com/*', 'https://music.youtube.com/*', 'https://youtu.be/*',
               'https://www.facebook.com/*', 'https://web.facebook.com/*', 'https://m.facebook.com/*', 'https://fb.watch/*',
               'https://www.tiktok.com/*', 'https://m.tiktok.com/*', 'https://vm.tiktok.com/*', 'https://vt.tiktok.com/*',
               'https://vimeo.com/*', 'https://player.vimeo.com/*', 'https://www.instagram.com/*',
               'https://*.pinterest.com/*', 'https://pin.it/*'];

chrome.runtime.onInstalled.addListener(() => {
  handshake();
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    const base = { contexts: ['page', 'link', 'video'], documentUrlPatterns: PAGES };
    chrome.contextMenus.create({ ...base, id: 'pull-video', title: 'pull. — download video' });
    chrome.contextMenus.create({ ...base, id: 'pull-audio', title: 'pull. — download audio (MP3)' });
    chrome.contextMenus.create({ ...base, id: 'pull-capture', title: 'pull. — capture this frame (full res)', contexts: ['page', 'video'] });
    chrome.contextMenus.create({ ...base, id: 'pull-snip', title: 'pull. — snip a part of this frame (full res)', contexts: ['page', 'video'] });
  });
});

chrome.contextMenus?.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'pull-capture') { captureActiveTab(); return; }
  if (info.menuItemId === 'pull-snip') { snipActiveTab(tab?.id); return; }
  let t = Sites.parse(info.linkUrl || '') || Sites.parse(info.pageUrl || tab?.url || '');
  if (!t && tab) {
    const st = await videoState(tab.id);
    if (st && st.link) t = Sites.parse(st.link);
  }
  if (!t) { notify('Not a video link', 'Open the video itself, or paste its link in pull.'); return; }
  const title = info.linkUrl ? t.url : (tab?.title || t.url).replace(/^\(\d+\)\s*/, '').replace(/ (?:[-|] |on )(YouTube|Facebook|TikTok|Vimeo|Pinterest)$/, '');
  startDownload({ url: t.url, title, options: info.menuItemId === 'pull-audio' ? { quality: 'audio' } : {} });
  notify('Started', title);
});

// ---------- updates (from the public Google Drive folders) ----------
// Files are named with their version (pull-setup-1.8.1.exe / pull-setup-mac-1.8.1.zip): a higher number = an update.
const UPDATE_GITHUB = 'mutesonix/pull.';   // owner/repo — releases are the primary source, Drive the fallback
const UPDATE_FOLDERS = { windows: '1ZAe0qln1QBMGh1baGjMTjkcPYlWGiqSm', darwin: '1wd8n3YSG8vTCnjCpZRlHm1kSboLluyDk' };
let updateState = { phase: 'idle' };   // idle | downloading | installing | restarting | error

const verGt = (a, b) => {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
};
function sendUpdateState() { chrome.runtime.sendMessage({ type: 'updateState', state: updateState }).catch(() => {}); }

async function checkUpdate(manual) {
  const s = await getSettings();
  if (!manual && s.autoUpdate === false) return null;
  const info = hostInfo || (hostInfo = await call('ping'));
  const folder = UPDATE_FOLDERS[info.platform];
  if (!folder && !/\//.test(UPDATE_GITHUB)) return { none: true };
  let r = null;
  if (/^[\w.-]+\/[\w.-]+$/.test(UPDATE_GITHUB)) { try { r = await call('checkUpdate', { github: UPDATE_GITHUB }); } catch {} }
  if ((!r || !r.latest) && folder) r = await call('checkUpdate', { folder });
  if (!r) return { none: true };
  const mine = chrome.runtime.getManifest().version;
  const avail = r.latest && verGt(r.latest, mine) ? { version: r.latest, fileId: r.fileId, url: r.url, name: r.name } : null;
  await chrome.storage.local.set({ update: avail, updateChecked: Date.now() });
  if (avail) {
    chrome.action.setBadgeText({ text: '↑' });
    chrome.action.setBadgeBackgroundColor?.({ color: '#D71921' });
    const { notifiedUpdate } = await chrome.storage.local.get('notifiedUpdate');
    if (notifiedUpdate !== avail.version) {
      await chrome.storage.local.set({ notifiedUpdate: avail.version });
      notify('Update available', `pull. ${avail.version} is ready — open pull. and press Update.`);
    }
  }
  return { latest: r.latest || null, current: mine, update: avail };
}

async function applyUpdate() {
  const { update } = await chrome.storage.local.get('update');
  if (!update) throw new Error('No update to install');
  updateState = { phase: 'downloading', percent: 0, version: update.version };
  sendUpdateState();
  try { await call('applyUpdate', { fileId: update.fileId, url: update.url, name: update.name }); }
  catch (e) { updateState = { phase: 'error', error: e.message, version: update.version }; sendUpdateState(); throw e; }
}

function onUpdateEvent(msg) {
  const v = updateState.version;
  if (msg.phase === 'downloading') updateState = { phase: 'downloading', percent: msg.percent || 0, version: v };
  else if (msg.phase === 'installing') updateState = { phase: 'installing', version: v };
  else if (msg.phase === 'launched') { updateState = { phase: 'restarting', version: v }; waitForNewHost(v); }
  else if (msg.phase === 'error') updateState = { phase: 'error', error: msg.error, version: v };
  sendUpdateState();
}

// the installer swaps the files; reconnect until the new helper answers, then reload the extension from disk
async function waitForNewHost(version) {
  const until = Date.now() + 4 * 60 * 1000;
  await new Promise(r => setTimeout(r, 4000));
  while (Date.now() < until) {
    try {
      if (port) { try { port.disconnect(); } catch {} port = null; }
      hostInfo = null;
      const p = await call('ping');
      if (p.host && !verGt(version, p.host)) {
        await chrome.storage.local.set({ update: null });
        chrome.runtime.reload();
        return;
      }
    } catch {}
    await new Promise(r => setTimeout(r, 3000));
  }
  updateState = { phase: 'error', error: 'The installer didn\'t finish — open pull. Setup to complete the update.', version };
  sendUpdateState();
}

chrome.alarms?.onAlarm.addListener(a => { if (a.name === 'pull-update') checkUpdate(false).catch(() => {}); });
function scheduleUpdateChecks() {
  chrome.alarms?.create('pull-update', { delayInMinutes: 2, periodInMinutes: 360 });
}
chrome.runtime.onStartup.addListener(scheduleUpdateChecks);
chrome.runtime.onInstalled.addListener(() => { scheduleUpdateChecks(); chrome.storage.local.set({ update: null }); });
