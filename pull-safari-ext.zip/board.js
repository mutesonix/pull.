// pull. — Board: every captured frame, sorted into folders. Folders, their order and notes live in
// Boards/library.json next to the day boards (the helper reads and writes it); a folder, or all of them
// as an overall, exports to a standalone board page that can be sent as is or printed to PDF.
const $ = s => document.querySelector(s);
const send = msg => chrome.runtime.sendMessage(msg).catch(e => ({ ok: false, error: e.message }));

let items = [];            // every capture, newest day first: { key, day, title, url, link, site, tc, w, h, low, file }
let byKey = new Map();
let lib = { v: 1, folders: [], notes: {}, hidden: [] };
let view = 'all';          // all | unsorted | hidden | day:YYYY-MM-DD | f:<folder id>
let sel = new Set();
let lastClick = null;
let shown = [];            // keys in the grid, in order
const thumbs = new Map();  // key -> data URL
const pals = new Map();    // key -> [hex…]

init();

async function init() {
  await load();
  route();
  addEventListener('hashchange', route);
  // a capture finishing anywhere adds it here
  let t = 0;
  chrome.runtime.onMessage.addListener(m => {
    if (m.type !== 'state') return;
    const done = Object.values(m.jobs || {}).some(j => j.kind === 'capture' && j.status === 'done' && j.board && !seenDone.has(j.id) && seenDone.add(j.id));
    if (done) { clearTimeout(t); t = setTimeout(async () => { await load(); render(); }, 600); }
  });
}
const seenDone = new Set();

async function load() {
  const r = await send({ type: 'boardList' });
  if (!r || !r.ok) { items = []; showEmpty('pull. isn’t connected', (r && r.error) || 'Open the pull. popup to check the helper.'); return; }
  items = r.items || [];
  byKey = new Map(items.map(it => [it.key, it]));
  const l = r.library || {};
  lib = { v: 1, folders: Array.isArray(l.folders) ? l.folders : [], notes: l.notes || {}, hidden: Array.isArray(l.hidden) ? l.hidden : [] };
  lib.folders.forEach(f => { f.keys = (f.keys || []).filter(k => byKey.has(k)); });
  const pc = $('#projChip');
  pc.textContent = r.project || ''; pc.classList.toggle('hidden', !r.project);
}

function route() {
  const h = decodeURIComponent(location.hash.slice(1));
  if (h.startsWith('day=')) view = 'day:' + h.slice(4);
  else if (h.startsWith('folder=') && lib.folders.some(f => f.id === h.slice(7))) view = 'f:' + h.slice(7);
  else if (['all', 'unsorted', 'hidden'].includes(h)) view = h;
  sel.clear();
  render();
}
const go = v => { location.hash = v.startsWith('f:') ? 'folder=' + v.slice(2) : v.startsWith('day:') ? 'day=' + v.slice(4) : v; };
const folderOf = v => v.startsWith('f:') ? lib.folders.find(f => f.id === v.slice(2)) : null;

// ---------------- saving ----------------
let saveT = 0;
function save() {
  const s = $('#saveState');
  s.className = 'save'; s.textContent = 'Saving…';
  clearTimeout(saveT);
  saveT = setTimeout(async () => {
    const r = await send({ type: 'boardSave', library: lib });
    s.className = 'save ' + (r && r.ok ? 'ok' : 'bad');
    s.textContent = r && r.ok ? 'Saved ✓' : 'Not saved — ' + ((r && r.error) || 'helper offline');
  }, 450);
}

// ---------------- sidebar ----------------
function renderSide() {
  const hidden = new Set(lib.hidden), inFolder = new Set(lib.folders.flatMap(f => f.keys));
  const vis = items.filter(it => !hidden.has(it.key));
  $('#nAll').textContent = vis.length;
  $('#nUns').textContent = vis.filter(it => !inFolder.has(it.key)).length;
  $('#nHid').textContent = hidden.size || '';
  document.querySelectorAll('.nav[data-view]').forEach(b => b.classList.toggle('on', b.dataset.view === view));

  const box = $('#folders');
  box.textContent = '';
  for (const f of lib.folders) {
    const b = document.createElement('button');
    b.className = 'nav' + (view === 'f:' + f.id ? ' on' : '');
    b.dataset.folder = f.id;
    b.innerHTML = '<span class="nm"></span><span class="n"></span>';
    b.querySelector('.nm').textContent = f.name;
    b.querySelector('.n').textContent = f.keys.length;
    b.onclick = () => go('f:' + f.id);
    b.ondblclick = () => renameInline(b, f);
    dropTarget(b, keys => addTo(f, keys, b));
    box.appendChild(b);
  }

  const days = [...new Set(items.map(it => it.day))];
  const db = $('#days');
  db.textContent = '';
  for (const d of days) {
    const b = document.createElement('button');
    b.className = 'nav' + (view === 'day:' + d ? ' on' : '');
    b.innerHTML = '<span class="nm"></span><span class="n"></span>';
    b.querySelector('.nm').textContent = dayLong(d);
    b.querySelector('.n').textContent = items.filter(it => it.day === d && !hidden.has(it.key)).length;
    b.onclick = () => go('day:' + d);
    db.appendChild(b);
  }
}
document.querySelectorAll('.nav[data-view]').forEach(b => { b.onclick = () => go(b.dataset.view); });
dropTarget($('.nav[data-view="hidden"]'), keys => { keys.forEach(k => { if (!lib.hidden.includes(k)) lib.hidden.push(k); }); save(); sel.clear(); render(); toast(keys.length + (keys.length === 1 ? ' frame' : ' frames') + ' hidden'); });

function dayLong(d) {
  const t = new Date(d + 'T12:00:00');
  return isNaN(t) ? d : t.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

function newFolder(keys = [], name) {
  const n = lib.folders.length + 1;
  const f = { id: Math.random().toString(36).slice(2, 9), name: name || 'Folder ' + n, keys: [...new Set(keys)] };
  lib.folders.push(f);
  save();
  return f;
}
$('#btnNew').onclick = () => { const f = newFolder(); go('f:' + f.id); setTimeout(() => editTitle(true), 60); };
$('#dropNew').onclick = $('#btnNew').onclick;
dropTarget($('#dropNew'), keys => { const f = newFolder(keys); toast('New folder with ' + keys.length + (keys.length === 1 ? ' frame' : ' frames')); go('f:' + f.id); setTimeout(() => editTitle(true), 60); });

function addTo(f, keys, el) {
  const before = f.keys.length;
  for (const k of keys) if (!f.keys.includes(k)) f.keys.push(k);
  const added = f.keys.length - before;
  save(); renderSide();
  const b = document.querySelector(`.nav[data-folder="${f.id}"]`) || el;
  if (b) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); }
  toast(added ? `Added ${added} to ${f.name}` : `Already in ${f.name}`);
}

function renameInline(btn, f) {
  const nm = btn.querySelector('.nm');
  const inp = document.createElement('input');
  inp.value = f.name;
  nm.replaceWith(inp);
  inp.focus(); inp.select();
  const done = ok => { if (ok && inp.value.trim()) { f.name = inp.value.trim().slice(0, 60); save(); } render(); };
  inp.onkeydown = e => { if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); };
  inp.onblur = () => done(true);
}

// ---------------- main view ----------------
function viewKeys() {
  const hidden = new Set(lib.hidden);
  const f = folderOf(view);
  if (f) return f.keys.slice();
  if (view === 'hidden') return items.filter(it => hidden.has(it.key)).map(it => it.key);
  if (view === 'unsorted') { const inF = new Set(lib.folders.flatMap(x => x.keys)); return items.filter(it => !hidden.has(it.key) && !inF.has(it.key)).map(it => it.key); }
  if (view.startsWith('day:')) return items.filter(it => it.day === view.slice(4) && !hidden.has(it.key)).map(it => it.key);
  return items.filter(it => !hidden.has(it.key)).map(it => it.key);
}

function matches(it, q) {
  if (!q) return true;
  return [it.title, it.site, lib.notes[it.key] || '', it.tc].join(' ').toLowerCase().includes(q);
}

function render() {
  if (view.startsWith('f:') && !folderOf(view)) view = 'all';
  renderSide();
  const f = folderOf(view);
  const title = f ? f.name : view === 'unsorted' ? 'Unsorted' : view === 'hidden' ? 'Hidden' : view.startsWith('day:') ? dayLong(view.slice(4)) : 'All frames';
  const h1 = $('#vTitle');
  h1.textContent = title;
  h1.contentEditable = f ? 'true' : 'false';
  h1.title = f ? 'Click to rename' : '';
  $('#btnDel').classList.toggle('hidden', !f);
  $('#btnExport').textContent = f ? 'Export board' : 'Export this view';
  $('#tip').textContent = f
    ? 'Drag to reorder · ✕ takes a frame out of this folder (it stays in All frames) · Click a frame to view it full screen'
    : view === 'hidden' ? '✕ puts a frame back'
    : 'Drag frames onto a folder (or + New folder) · Click the circle to pick several · ✕ hides a frame';
  document.title = title + ' · pull. board';

  const q = $('#q').value.trim().toLowerCase();
  shown = viewKeys().filter(k => byKey.has(k) && matches(byKey.get(k), q));
  const grid = $('#grid');
  grid.textContent = '';
  const groupDays = !f && !view.startsWith('day:') && !q;
  let lastDay = null, i = 0;
  for (const k of shown) {
    const it = byKey.get(k);
    if (groupDays && it.day !== lastDay) {
      lastDay = it.day;
      const hd = document.createElement('div');
      hd.className = 'day-h';
      hd.innerHTML = '<span></span><small></small>';
      hd.firstChild.textContent = dayLong(it.day);
      hd.lastChild.textContent = shown.filter(x => byKey.get(x).day === it.day).length + ' FRAMES';
      grid.appendChild(hd);
    }
    grid.appendChild(card(it, i++));
  }
  const n = shown.length;
  $('#vCount').textContent = n + (n === 1 ? ' frame' : ' frames');
  syncSel();
  if (!items.length) showEmpty('No captures yet', 'Capture a frame on any video (Alt+Shift+S) and it lands here.');
  else if (!n) showEmpty(f ? 'Empty folder' : q ? 'Nothing found' : 'Nothing here', f ? 'Drag frames onto this folder in the sidebar.' : q ? 'Try another word.' : '');
  else $('#empty').classList.add('hidden');
  observe();
}

function showEmpty(t, s) {
  const e = $('#empty');
  e.innerHTML = '<b></b><span></span>';
  e.firstChild.textContent = t; e.lastChild.textContent = s;
  e.classList.remove('hidden');
}

function card(it, i) {
  const el = document.createElement('figure');
  el.className = 'card' + (sel.has(it.key) ? ' sel' : '');
  el.style.setProperty('--i', Math.min(i, 16));
  el.dataset.k = it.key;
  el.draggable = true;
  el.tabIndex = 0;
  el.innerHTML = `<img class="th-img load" alt=""><button class="ck" type="button" aria-label="Select"></button><button class="x" type="button"></button><span class="badge"></span>
    <figcaption class="cap"><div class="t"></div><div class="row"></div><div class="pal"></div><div class="note" contenteditable="true" spellcheck="false"></div></figcaption>`;
  const img = el.querySelector('img');
  img.alt = it.title + ' at ' + it.tc;
  if (thumbs.has(it.key)) setImg(img, it.key);
  el.querySelector('.t').textContent = it.title;
  el.querySelector('.t').title = it.title;
  const row = el.querySelector('.row');
  if (it.site) row.appendChild(Object.assign(document.createElement('span'), { textContent: it.site }));
  if (it.link) { const a = document.createElement('a'); a.href = it.link; a.target = '_blank'; a.rel = 'noopener'; a.textContent = it.tc + ' ↗'; a.title = 'Open the video at this moment'; row.appendChild(a); }
  else row.appendChild(Object.assign(document.createElement('span'), { textContent: it.tc }));
  if (it.w) row.appendChild(Object.assign(document.createElement('span'), { textContent: it.w + '×' + it.h }));
  const inF = lib.folders.filter(x => x.keys.includes(it.key));
  if (!view.startsWith('f:') && inF.length) {
    const bd = el.querySelector('.badge');
    inF.slice(0, 2).forEach(x => bd.appendChild(Object.assign(document.createElement('i'), { textContent: x.name })));
    if (inF.length > 2) bd.appendChild(Object.assign(document.createElement('i'), { textContent: '+' + (inF.length - 2) }));
  }
  if (pals.has(it.key)) swatches(el.querySelector('.pal'), pals.get(it.key));
  const note = el.querySelector('.note');
  note.textContent = lib.notes[it.key] || '';
  note.addEventListener('input', () => { const v = note.textContent.trim(); if (v) lib.notes[it.key] = v; else delete lib.notes[it.key]; save(); });
  note.addEventListener('keydown', e => e.stopPropagation());
  const x = el.querySelector('.x');
  const f = folderOf(view);
  x.textContent = view === 'hidden' ? '↺' : '✕';
  x.title = f ? 'Take out of ' + f.name : view === 'hidden' ? 'Show again' : 'Hide';
  x.onclick = e => { e.stopPropagation(); removeKeys(sel.has(it.key) ? [...sel] : [it.key]); };
  el.querySelector('.ck').onclick = e => { e.stopPropagation(); pick(it.key, e.shiftKey); };
  img.onclick = e => { if (e.metaKey || e.ctrlKey || e.shiftKey) pick(it.key, e.shiftKey); else viewer(it.key); };
  el.addEventListener('click', e => { if (e.target === el || e.target.classList.contains('cap')) pick(it.key, e.shiftKey); });
  el.addEventListener('dragstart', e => dragStart(e, it.key, el));
  el.addEventListener('dragend', () => { document.querySelectorAll('.dragging,.before,.after,.drop').forEach(n => n.classList.remove('dragging', 'before', 'after', 'drop')); });
  if (f) reorderTarget(el, f);
  return el;
}

function removeKeys(keys) {
  const f = folderOf(view);
  if (f) { f.keys = f.keys.filter(k => !keys.includes(k)); toast(keys.length + (keys.length === 1 ? ' frame' : ' frames') + ' taken out of ' + f.name); }
  else if (view === 'hidden') { lib.hidden = lib.hidden.filter(k => !keys.includes(k)); toast('Shown again'); }
  else { keys.forEach(k => { if (!lib.hidden.includes(k)) lib.hidden.push(k); }); toast(keys.length + (keys.length === 1 ? ' frame' : ' frames') + ' hidden · find them under Hidden'); }
  keys.forEach(k => sel.delete(k));
  save(); render();
}

// ---------------- selection ----------------
function pick(key, range) {
  if (range && lastClick && shown.includes(lastClick)) {
    const a = shown.indexOf(lastClick), b = shown.indexOf(key);
    shown.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(k => sel.add(k));
  } else if (sel.has(key)) sel.delete(key); else sel.add(key);
  lastClick = key;
  syncSel();
}
function syncSel() {
  for (const k of [...sel]) if (!shown.includes(k)) sel.delete(k);
  document.querySelectorAll('.card').forEach(c => c.classList.toggle('sel', sel.has(c.dataset.k)));
  $('#vSel').textContent = sel.size ? sel.size + ' selected · drag onto a folder' : '';
  document.body.classList.toggle('selecting', sel.size > 0);
}
addEventListener('keydown', e => {
  if ($('#lb').classList.contains('on')) return;
  const t = e.target;
  if (t.isContentEditable || /^(INPUT|TEXTAREA)$/.test(t.tagName)) return;
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'a') { e.preventDefault(); shown.forEach(k => sel.add(k)); syncSel(); }
  else if (e.key === 'Escape') { sel.clear(); syncSel(); }
  else if ((e.key === 'Delete' || e.key === 'Backspace') && sel.size) { e.preventDefault(); removeKeys([...sel]); }
});

// ---------------- drag & drop ----------------
let dragKeys = [];
function dragStart(e, key, el) {
  if (!sel.has(key)) { sel.clear(); sel.add(key); syncSel(); }
  dragKeys = shown.filter(k => sel.has(k));
  e.dataTransfer.effectAllowed = 'copyMove';
  e.dataTransfer.setData('text/x-pull-keys', JSON.stringify(dragKeys));
  e.dataTransfer.setData('text/plain', dragKeys.map(k => byKey.get(k).link || '').join('\n'));
  if (dragKeys.length > 1) {
    const g = document.createElement('div');
    g.className = 'drag-ghost'; g.textContent = dragKeys.length + ' FRAMES';
    document.body.appendChild(g);
    e.dataTransfer.setDragImage(g, 20, 16);
    setTimeout(() => g.remove());
  }
  requestAnimationFrame(() => document.querySelectorAll('.card').forEach(c => c.classList.toggle('dragging', dragKeys.includes(c.dataset.k))));
}
function keysFrom(e) {
  try { return JSON.parse(e.dataTransfer.getData('text/x-pull-keys') || '[]'); } catch { return dragKeys; }
}
function dropTarget(el, fn) {
  el.addEventListener('dragover', e => { if (!e.dataTransfer.types.includes('text/x-pull-keys')) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; el.classList.add('drop'); });
  el.addEventListener('dragleave', () => el.classList.remove('drop'));
  el.addEventListener('drop', e => { e.preventDefault(); el.classList.remove('drop'); const k = keysFrom(e); if (k.length) fn(k); });
}
function reorderTarget(el, f) {
  el.addEventListener('dragover', e => {
    if (!e.dataTransfer.types.includes('text/x-pull-keys')) return;
    e.preventDefault(); e.dataTransfer.dropEffect = 'move';
    const r = el.getBoundingClientRect(), after = e.clientX > r.left + r.width / 2;
    el.classList.toggle('after', after); el.classList.toggle('before', !after);
  });
  el.addEventListener('dragleave', () => el.classList.remove('before', 'after'));
  el.addEventListener('drop', e => {
    e.preventDefault();
    const after = el.classList.contains('after');
    el.classList.remove('before', 'after');
    const moving = keysFrom(e).filter(k => byKey.has(k));
    if (!moving.length) return;
    const rest = f.keys.filter(k => !moving.includes(k));
    let at = rest.indexOf(el.dataset.k);
    if (at < 0) at = rest.length; else if (after) at++;
    rest.splice(at, 0, ...moving);
    f.keys = rest;
    save(); render();
  });
}
// dropping on empty grid space in a folder puts frames at the end
$('#grid').addEventListener('dragover', e => { if (folderOf(view) && e.target === $('#grid') && e.dataTransfer.types.includes('text/x-pull-keys')) e.preventDefault(); });
$('#grid').addEventListener('drop', e => {
  const f = folderOf(view);
  if (!f || e.target !== $('#grid')) return;
  e.preventDefault();
  const moving = keysFrom(e);
  f.keys = f.keys.filter(k => !moving.includes(k)).concat(moving);
  save(); render();
});

// ---------------- header actions ----------------
function editTitle(selectAll) {
  const h1 = $('#vTitle');
  if (h1.contentEditable !== 'true') return;
  h1.focus();
  if (selectAll) { const r = document.createRange(); r.selectNodeContents(h1); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }
}
$('#vTitle').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); e.target.blur(); } if (e.key === 'Escape') { e.target.textContent = folderOf(view)?.name || ''; e.target.blur(); } });
$('#vTitle').addEventListener('blur', () => {
  const f = folderOf(view);
  if (!f) return;
  const v = $('#vTitle').textContent.trim().slice(0, 60);
  if (v && v !== f.name) { f.name = v; save(); renderSide(); }
  else $('#vTitle').textContent = f.name;
});
$('#btnDel').onclick = () => {
  const f = folderOf(view);
  if (!f) return;
  const b = $('#btnDel');
  if (!b.dataset.sure) { b.dataset.sure = '1'; b.textContent = 'Press again to delete'; setTimeout(() => { delete b.dataset.sure; b.textContent = 'Delete folder'; }, 2500); return; }
  delete b.dataset.sure; b.textContent = 'Delete folder';
  lib.folders = lib.folders.filter(x => x !== f);
  save();
  toast('Deleted ' + f.name + ' · the frames are still in All frames');
  go('all');
};
$('#q').addEventListener('input', () => render());
$('#btnHex').onclick = () => { document.body.classList.toggle('hexes'); $('#btnHex').classList.toggle('on'); };

async function exportBoard(name, sections) {
  sections = sections.filter(s => s.keys.length);
  if (!sections.length) { toast('Nothing to export yet'); return; }
  toast('Exporting…');
  const notes = {};
  sections.forEach(s => s.keys.forEach(k => { if (lib.notes[k]) notes[k] = lib.notes[k]; }));
  const r = await send({ type: 'boardExport', name, sections, notes });
  toast(r && r.ok ? 'Saved ' + r.path.split(/[\\/]/).pop() + ' in Boards/Exports' : 'Export failed — ' + ((r && r.error) || 'helper offline'), 3800);
}
$('#btnExport').onclick = () => {
  const f = folderOf(view);
  exportBoard($('#vTitle').textContent.trim() || 'Board', [{ name: '', keys: f ? f.keys : shown }]);
};
$('#btnOverall').onclick = () => {
  if (!lib.folders.some(f => f.keys.length)) { toast('Make a folder first — the overall has a section per folder'); return; }
  const proj = $('#projChip').textContent.trim();
  exportBoard((proj ? proj + ' — ' : '') + 'Overall', lib.folders.map(f => ({ name: f.name, keys: f.keys })));
};

// ---------------- thumbnails (lazy) ----------------
let io = null, inflight = 0;
const want = [];
function observe() {
  io?.disconnect();
  io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    io.unobserve(e.target);
    const k = e.target.closest('.card')?.dataset.k;
    if (k && !thumbs.has(k)) { want.push(k); pump(); }
  }), { rootMargin: '600px 0px' });
  document.querySelectorAll('.card .th-img.load').forEach(img => io.observe(img));
}
async function pump() {
  while (inflight < 4 && want.length) {
    const k = want.shift();
    if (thumbs.has(k)) continue;
    inflight++;
    send({ type: 'boardThumb', key: k }).then(r => {
      if (r && r.ok && r.thumb) {
        thumbs.set(k, 'data:image/jpeg;base64,' + r.thumb);
        document.querySelectorAll(`.card[data-k="${CSS.escape(k)}"] .th-img`).forEach(img => setImg(img, k));
      }
    }).finally(() => { inflight--; pump(); });
  }
}
function setImg(img, k) {
  img.src = thumbs.get(k);
  img.classList.remove('load');
  const done = () => {
    if (!pals.has(k)) { try { pals.set(k, palette(img)); } catch { pals.set(k, []); } }
    const c = img.closest('.card');
    if (c) swatches(c.querySelector('.pal'), pals.get(k));
  };
  img.complete && img.naturalWidth ? done() : img.addEventListener('load', done, { once: true });
}

// ---------------- palette ----------------
const hex = c => '#' + c.map(v => Math.round(v).toString(16).padStart(2, '0')).join('').toUpperCase();
function palette(img) {
  const w = 72, h = Math.max(1, Math.round(72 * img.naturalHeight / img.naturalWidth));
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const cx = cv.getContext('2d', { willReadFrequently: true }); cx.drawImage(img, 0, 0, w, h);
  const d = cx.getImageData(0, 0, w, h).data, px = [];
  for (let i = 0; i < d.length; i += 4) px.push([d[i], d[i + 1], d[i + 2]]);
  let cs = Array.from({ length: 5 }, (_, k) => px[Math.floor((k + .5) * px.length / 5)].slice()), cnt = [];
  for (let it = 0; it < 10; it++) {
    const sum = cs.map(() => [0, 0, 0]); cnt = cs.map(() => 0);
    for (const p of px) {
      let b = 0, bd = 1e9;
      cs.forEach((c, k) => { const dd = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2; if (dd < bd) { bd = dd; b = k; } });
      sum[b][0] += p[0]; sum[b][1] += p[1]; sum[b][2] += p[2]; cnt[b]++;
    }
    cs = cs.map((c, k) => cnt[k] ? sum[k].map(v => v / cnt[k]) : px[Math.floor(Math.random() * px.length)].slice());
  }
  return cs.map((c, k) => [hex(c), cnt[k]]).sort((a, b) => b[1] - a[1]).map(x => x[0]);
}
function swatches(box, cols) {
  box.textContent = '';
  (cols || []).forEach(c => {
    const b = document.createElement('button'); b.type = 'button'; b.style.background = c; b.title = 'Copy ' + c;
    const t = document.createElement('span'); t.textContent = c; b.appendChild(t);
    b.onclick = e => { e.stopPropagation(); navigator.clipboard.writeText(c).catch(() => {}); b.classList.add('ok'); t.textContent = 'COPIED'; setTimeout(() => { b.classList.remove('ok'); t.textContent = c; }, 1200); };
    box.appendChild(b);
  });
}

// ---------------- viewer ----------------
let at = -1;
function viewer(key) {
  at = shown.indexOf(key);
  if (at < 0) return;
  const it = byKey.get(key);
  $('#lbImg').src = thumbs.get(key) || '';
  $('#lbT').textContent = it.title;
  const row = $('#lbRow');
  row.textContent = '';
  if (it.site) row.appendChild(Object.assign(document.createElement('span'), { textContent: it.site }));
  if (it.link) { const a = document.createElement('a'); a.href = it.link; a.target = '_blank'; a.rel = 'noopener'; a.textContent = it.tc + ' ↗'; row.appendChild(a); }
  if (it.w) row.appendChild(Object.assign(document.createElement('span'), { textContent: it.w + '×' + it.h }));
  $('#lbN').textContent = (at + 1) + ' / ' + shown.length;
  swatches($('#lbPal'), pals.get(key));
  $('#lbReveal').onclick = () => send({ type: 'reveal', path: it.file });
  $('#lb').classList.add('on');
  if (!thumbs.has(key)) { want.unshift(key); pump(); }
}
const step = d => { if (shown.length) viewer(shown[(at + d + shown.length) % shown.length]); };
const closeLb = () => $('#lb').classList.remove('on');
$('#lbPrev').onclick = () => step(-1);
$('#lbNext').onclick = () => step(1);
$('#lbX').onclick = closeLb;
$('#lb').addEventListener('click', e => { if (e.target.id === 'lb' || e.target.tagName === 'FIGURE') closeLb(); });
addEventListener('keydown', e => {
  if (!$('#lb').classList.contains('on')) return;
  if (e.key === 'Escape') closeLb(); else if (e.key === 'ArrowRight') step(1); else if (e.key === 'ArrowLeft') step(-1);
});

// ---------------- toast ----------------
let toastT = 0;
function toast(msg, hold = 2200) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), hold);
}
