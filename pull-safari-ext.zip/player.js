// pull. — buttons inside the video player · by SUNN. (Trithaset Chaimongkol)
// YouTube: native-looking buttons in the player's right-hand controls, plus IN / OUT brackets on its timeline.
// Facebook / TikTok / Vimeo: a small pull. bar that appears over a video on hover.
(() => {
  if (window.__pullPlayer) return;
  window.__pullPlayer = true;

  const host = location.hostname;
  const IS_YT = /(^|\.)youtube\.com$/.test(host) && host !== 'music.youtube.com';
  let enabled = true;

  // ---------- icons ----------
  const ARROW = ['...#...', '...#...', '...#...', '##.#.##', '.#####.', '..###..', '...#..R'];
  function arrowSVG(size, cell, ox, oy, r) {
    let d = '';
    ARROW.forEach((row, y) => [...row].forEach((v, x) => {
      if (v === '.') return;
      const cx = ox + cell * (x + .5), cy = oy + cell * (y + .5);
      d += `<circle cx="${cx}" cy="${cy}" r="${v === 'R' ? r * 1.25 : r}" fill="${v === 'R' ? '#E30713' : '#fff'}"/>`;
    }));
    return `<svg viewBox="0 0 ${size} ${size}" width="100%" height="100%" aria-hidden="true">${d}</svg>`;
  }
  const CAPTURE = (size) => {
    const s = size, k = s * .26, c = s / 2, l = s * .1;
    const p = (sx, sy) => `M${c + sx * k} ${c + sy * (k - l)}V${c + sy * k}H${c + sx * (k - l)}`;
    return `<svg viewBox="0 0 ${s} ${s}" width="100%" height="100%" aria-hidden="true"><path d="${p(-1, -1)}${p(1, -1)}${p(1, 1)}${p(-1, 1)}" fill="none" stroke="#fff" stroke-width="${s * .055}" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${c}" cy="${c}" r="${s * .075}" fill="none" stroke="#fff" stroke-width="${s * .05}"/><circle cx="${c + k * .95}" cy="${c - k * 1.02}" r="${s * .045}" fill="#E30713"/></svg>`;
  };

  // snip: a dashed box with a corner handle and the red dot
  const SNIP = (s) => {
    const a = s * .22, b = s * .78, w = s * .055;
    return `<svg viewBox="0 0 ${s} ${s}" width="100%" height="100%" aria-hidden="true"><rect x="${a}" y="${a}" width="${b - a}" height="${b - a}" rx="${s * .04}" fill="none" stroke="#fff" stroke-width="${w}" stroke-dasharray="${s * .085} ${s * .07}" stroke-linecap="round"/><path d="M${b - s * .16} ${b}H${b}V${b - s * .16}" fill="none" stroke="#fff" stroke-width="${w * 1.5}" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${a}" cy="${a}" r="${s * .05}" fill="#E30713"/></svg>`;
  };

  // trim: an IN bracket and an OUT bracket with the red dot between
  const TRIM = (s) => {
    const a = s * .3, b = s * .7, t = s * .28, btm = s * .72, f = s * .09;
    return `<svg viewBox="0 0 ${s} ${s}" width="100%" height="100%" aria-hidden="true"><path d="M${a + f} ${t}H${a}V${btm}H${a + f}M${b - f} ${t}H${b}V${btm}H${b - f}" fill="none" stroke="#fff" stroke-width="${s * .06}" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${s / 2}" cy="${s / 2}" r="${s * .06}" fill="#E30713"/></svg>`;
  };

  // ---------- toast (one per page, shown over the player in use) ----------
  const toastHost = document.createElement('div');
  toastHost.style.cssText = 'position:fixed;z-index:2147483647;top:0;left:0;pointer-events:none';
  const tRoot = toastHost.attachShadow({ mode: 'open' });
  tRoot.innerHTML = `<style>
    .t { position: fixed; display: flex; align-items: center; gap: 10px; padding: 9px 14px 9px 12px; border-radius: 999px;
         background: rgba(0,0,0,.82); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,.14);
         color: #f2f2f0; font: 600 12px/1 ui-monospace, "SF Mono", Consolas, monospace; letter-spacing: .08em; text-transform: uppercase;
         opacity: 0; transform: translateY(-6px) scale(.98); transition: opacity .3s cubic-bezier(.33,0,.25,1), transform .45s cubic-bezier(.33,0,.25,1); white-space: nowrap; }
    .t.on { opacity: 1; transform: none; }
    .lg { font: 800 15px/1 ui-monospace, monospace; letter-spacing: .02em; text-transform: none; display: inline-flex; align-items: baseline; }
    .lg i { width: 4px; height: 4px; border-radius: 50%; background: #E30713; margin-left: 2px; display: inline-block; }
    .dots { display: flex; gap: 3px; }
    .dots b { width: 4px; height: 4px; border-radius: 50%; background: rgba(255,255,255,.22); transition: background .2s; }
    .dots b.f { background: #f2f2f0; } .dots b.r { background: #E30713; }
    .err { color: #ff8a8f; }
  </style><div class="t" id="t"><span class="lg">pull<i></i></span><span id="msg"></span><span class="dots" id="dots"></span></div>`;
  const tEl = tRoot.getElementById('t'), tMsg = tRoot.getElementById('msg'), tDots = tRoot.getElementById('dots');
  for (let i = 0; i < 10; i++) tDots.appendChild(document.createElement('b'));
  let tHide = 0, tAnchor = null, tJob = null;
  function placeToast() {
    if (!tAnchor || !tAnchor.isConnected) return;
    const r = tAnchor.getBoundingClientRect();
    tEl.style.top = Math.max(8, r.top + 14) + 'px';
    tEl.style.left = 'auto';
    tEl.style.right = Math.max(8, innerWidth - r.right + 14) + 'px';
  }
  function toast(anchor, msg, pct = null, err = false, hold = 2600) {
    if (!toastHost.isConnected) document.documentElement.appendChild(toastHost);
    tAnchor = anchor; placeToast();
    tMsg.textContent = msg; tMsg.className = err ? 'err' : '';
    tDots.style.display = pct == null ? 'none' : 'flex';
    if (pct != null) [...tDots.children].forEach((b, i) => { b.className = i < Math.round(pct / 10) ? 'f' : (i === Math.round(pct / 10) ? 'r' : ''); });
    tEl.classList.add('on');
    clearTimeout(tHide);
    if (hold) tHide = setTimeout(() => tEl.classList.remove('on'), hold);
  }
  addEventListener('scroll', placeToast, { passive: true, capture: true });
  addEventListener('resize', placeToast, { passive: true });

  // job updates pushed from the background worker
  chrome.runtime.onMessage.addListener(m => {
    if (!m || m.type !== 'pullJob' || !tJob || m.job.id !== tJob.id) return;
    const j = m.job, a = tJob.anchor;
    if (j.status === 'error') { toast(a, 'Failed — open pull. for details', null, true, 5000); tJob = null; return; }
    if (j.status === 'done') { toast(a, j.kind === 'capture' ? (tJob.snip ? 'Snip saved · ' + j.width + '×' + j.height : 'Frame saved') + (j.copied ? ' · copied' : '') : j.kind === 'loop' ? (j.format || 'gif').toUpperCase() + ' saved' : 'Saved', 100, false, 3200); tJob = null; return; }
    const pct = typeof j.percent === 'number' ? j.percent : null;
    const label = j.kind === 'capture' ? (tJob.snip ? (/source|fresh/.test(j.phase || '') ? 'Getting full res' : 'Snipping') : 'Capturing') : j.kind === 'loop' ? (/making/.test(j.phase) ? 'Making ' + (j.format || 'gif').toUpperCase() : 'Fetching range')
      : (j.phase && /convert/i.test(j.phase) ? 'Converting' : 'Downloading');
    toast(a, label + (pct != null ? ' ' + Math.floor(pct) + '%' : ''), pct ?? 0, false, 0);
  });

  // ---------- what video is this? ----------
  function urlFor(video) {
    if (IS_YT) { const t = Sites.parse(location.href); return t && t.url; }
    const here = Sites.parse(location.href);
    // on a feed, the nearest link that points at a single video (FB timestamp, TikTok card)
    let el = video;
    for (let i = 0; el && i < 14; i++, el = el.parentElement) {
      const links = el.querySelectorAll ? el.querySelectorAll('a[href]') : [];
      for (const a of links) { const t = Sites.parse(a.href); if (t && !t.playlistOnly) return t.url; }
    }
    return here && !here.playlistOnly ? here.url : null;
  }
  const cleanTitle = () => (document.title || '').replace(/^\(\d+\)\s*/, '').replace(/ (?:[-|] |on )(YouTube|Facebook|TikTok|Vimeo|Instagram|Pinterest)$/, '').trim();

  async function send(msg) {
    try { return await chrome.runtime.sendMessage(msg); }
    catch (e) { return { ok: false, error: /context invalidated/i.test(e.message) ? 'pull. was updated — reload this page' : e.message }; }
  }
  async function doPull(video, anchor) {
    const url = urlFor(video);
    if (!url) { toast(anchor, 'Open the video itself first', null, true); return; }
    toast(anchor, 'Adding…', 0, false, 0);
    const r = await send({ type: 'download', url, title: cleanTitle(), fromPlayer: true });
    if (!r || !r.ok) { toast(anchor, (r && r.error) || 'pull. is not connected', null, true, 5000); return; }
    tJob = { id: r.id, anchor };
    toast(anchor, 'Added to queue', 0, false, 0);
  }
  // shutter: a quick white flash over the video, then the frame shrinks away toward the toolbar's pull. icon
  const still = matchMedia('(prefers-reduced-motion: reduce)');
  function shutter(video) {
    if (!video || !video.isConnected) return;
    const r = video.getBoundingClientRect();
    if (r.width < 40 || r.height < 30) return;
    const box = document.createElement('div');
    box.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;z-index:2147483646;pointer-events:none;contain:strict`;
    const flash = document.createElement('div');
    flash.style.cssText = 'position:absolute;inset:0;background:#fff';
    box.appendChild(flash);
    document.documentElement.appendChild(box);
    flash.animate([{ opacity: .85 }, { opacity: 0 }], { duration: still.matches ? 160 : 280, easing: 'ease-out', fill: 'forwards' });
    if (still.matches) { setTimeout(() => box.remove(), 200); return; }
    const cv = document.createElement('canvas');
    const k = Math.min(1, 480 / r.width);
    cv.width = Math.round(r.width * k); cv.height = Math.round(r.height * k);
    try { cv.getContext('2d').drawImage(video, 0, 0, cv.width, cv.height); } catch { box.remove(); return; }
    cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border-radius:10px;box-shadow:0 18px 50px rgba(0,0,0,.55);transform-origin:100% 0';
    box.insertBefore(cv, flash);
    const dx = innerWidth - 56 - r.right, dy = 8 - r.top;
    cv.animate([
      { transform: 'none', opacity: 1, offset: 0 },
      { transform: 'scale(.94)', opacity: 1, offset: .22 },
      { transform: `translate(${dx}px, ${dy}px) scale(.06)`, opacity: .2 },
    ], { duration: 720, easing: 'cubic-bezier(.55,0,.25,1)', fill: 'forwards' }).finished.then(() => box.remove(), () => box.remove());
  }
  // the largest playing video on the page, for the keyboard shortcuts
  function mainVideo() {
    let best = null, area = 0;
    for (const v of document.querySelectorAll('video')) {
      const r = v.getBoundingClientRect(), a = r.width * r.height;
      if (a > area) { area = a; best = v; }
    }
    return best;
  }
  chrome.runtime.onMessage.addListener(m => {
    if (!m || m.type !== 'pullKey') return;
    const v = mainVideo();
    if (!v) return;
    const anchor = (IS_YT && v.closest('#movie_player')) || v;
    if (m.kind === 'capture') shutter(v);
    if (m.error) { toast(anchor, m.error, null, true, 4000); return; }
    if (m.id) { tJob = { id: m.id, anchor }; toast(anchor, m.kind === 'capture' ? 'Capturing' : 'Making ' + (m.format || 'gif').toUpperCase() + '…', 0, false, 0); }
  });
  async function doCapture(video, anchor) {
    const url = urlFor(video);
    if (!url) { toast(anchor, 'Open the video itself first', null, true); return; }
    shutter(video);
    const time = video ? video.currentTime : null;
    toast(anchor, 'Capturing', 0, false, 0);
    const r = await send({ type: 'capture', url, title: cleanTitle(), time, referer: window.top === window ? '' : (document.referrer || ''), fromPlayer: true });
    if (!r || !r.ok) { toast(anchor, (r && r.error) || 'pull. is not connected', null, true, 5000); return; }
    tJob = { id: r.id, anchor };
  }

  // ---------- snip: drag a box over the video, like Snipping Tool ----------
  // The box is measured against the picture itself (letterbox / object-fit aware) and sent as fractions of the frame,
  // so the host cuts it out of the video's full-resolution frame — never out of the screen or the player's quality.
  const snipHost = document.createElement('div');
  snipHost.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:none';
  const sRoot = snipHost.attachShadow({ mode: 'open' });
  sRoot.innerHTML = `<style>
    .sn { position: fixed; pointer-events: auto; cursor: crosshair; overflow: hidden; touch-action: none; outline: 1px solid rgba(255,255,255,.35); }
    .shade { position: absolute; inset: 0; background: rgba(0,0,0,.42); transition: opacity .2s; }
    .sn.has .shade { opacity: 0; }
    .sel { position: absolute; display: none; box-shadow: 0 0 0 200vmax rgba(0,0,0,.42); outline: 1px solid #f2f2f0; }
    .sn.has .sel { display: block; }
    .sel i { position: absolute; width: 7px; height: 7px; background: #f2f2f0; border-radius: 50%; }
    .sel i:nth-child(1) { left: -4px; top: -4px; background: #E30713; } .sel i:nth-child(2) { right: -4px; top: -4px; }
    .sel i:nth-child(3) { left: -4px; bottom: -4px; } .sel i:nth-child(4) { right: -4px; bottom: -4px; }
    .sz, .hint { position: absolute; padding: 6px 10px; border-radius: 999px; background: rgba(0,0,0,.82); border: 1px solid rgba(255,255,255,.14);
                 color: #f2f2f0; font: 600 11px/1 ui-monospace, "SF Mono", Consolas, monospace; letter-spacing: .08em; white-space: nowrap; pointer-events: none; }
    .sz { display: none; } .sn.has .sz { display: block; }
    .hint { left: 50%; top: 12px; transform: translateX(-50%); display: flex; gap: 10px; align-items: center; text-transform: uppercase; transition: opacity .2s; }
    .sn.drag .hint { opacity: 0; }
    .hint b { font: 800 13px/1 ui-monospace, monospace; letter-spacing: .02em; text-transform: none; display: inline-flex; align-items: baseline; }
    .hint b i { width: 4px; height: 4px; border-radius: 50%; background: #E30713; margin-left: 2px; display: inline-block; }
    .hint em { font-style: normal; color: rgba(242,242,240,.55); }
    .sn.narrow .hint em, .sn.narrow #src { display: none; }
    .fl { position: absolute; background: #fff; pointer-events: none; }
  </style><div class="sn" id="sn"><div class="shade"></div><div class="sel" id="sel"><i></i><i></i><i></i><i></i></div><span class="sz" id="sz"></span>
    <div class="hint" id="hint"><b>pull<i></i></b><span>Drag a box</span><em>Enter = whole frame · Esc</em><span id="src"></span></div></div>`;
  const snEl = sRoot.getElementById('sn'), selEl = sRoot.getElementById('sel'), szEl = sRoot.getElementById('sz'), srcEl = sRoot.getElementById('src');
  let sn = null;   // { video, anchor, url, time, wasPlaying, src: {w, h}, sel: {x, y, w, h} in fractions, from }
  // where the picture really is on screen: the element box minus letterboxing (object-fit, centred)
  function picRect(v) {
    const r = v.getBoundingClientRect(), vw = v.videoWidth, vh = v.videoHeight;
    let w = r.width, h = r.height;
    if (vw && vh) {
      const fit = getComputedStyle(v).objectFit;
      if (fit !== 'fill') {
        let k = fit === 'cover' ? Math.max(r.width / vw, r.height / vh) : Math.min(r.width / vw, r.height / vh);
        if (fit === 'none') k = 1; else if (fit === 'scale-down') k = Math.min(1, k);
        w = vw * k; h = vh * k;
      }
    }
    const pic = { left: r.left + (r.width - w) / 2, top: r.top + (r.height - h) / 2, width: w, height: h };
    // what of it can be drawn on: inside the element and the window
    const l = Math.max(pic.left, r.left, 0), t = Math.max(pic.top, r.top, 0);
    const rr = Math.min(pic.left + w, r.right, innerWidth), b = Math.min(pic.top + h, r.bottom, innerHeight);
    return { pic, vis: { left: l, top: t, width: Math.max(0, rr - l), height: Math.max(0, b - t) } };
  }
  function snipDraw() {
    if (!sn) return;
    if (!sn.video.isConnected) { snipEnd(false); return; }
    const { pic, vis } = picRect(sn.video);
    sn.pic = pic; sn.vis = vis;
    Object.assign(snEl.style, { left: vis.left + 'px', top: vis.top + 'px', width: vis.width + 'px', height: vis.height + 'px' });
    const q = sn.sel;
    snEl.classList.toggle('narrow', vis.width < 560);
    snEl.classList.toggle('has', !!q);
    if (!q) return;
    const x = pic.left - vis.left + q.x * pic.width, y = pic.top - vis.top + q.y * pic.height, w = q.w * pic.width, h = q.h * pic.height;
    Object.assign(selEl.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    const sw = sn.src.w || sn.video.videoWidth, sh = sn.src.h || sn.video.videoHeight;
    szEl.textContent = `${Math.max(1, Math.round(q.w * sw))} × ${Math.max(1, Math.round(q.h * sh))} PX`;
    const below = y + h + 34 < vis.height;
    szEl.style.left = Math.max(6, Math.min(x, vis.width - 150)) + 'px';
    szEl.style.top = (below ? y + h + 8 : Math.max(6, y - 30)) + 'px';
  }
  // pointer → fraction of the picture, kept inside the part that is on screen
  function snipAt(e) {
    const { pic, vis } = sn;
    const cx = Math.max(vis.left, Math.min(vis.left + vis.width, e.clientX)), cy = Math.max(vis.top, Math.min(vis.top + vis.height, e.clientY));
    return { x: (cx - pic.left) / pic.width, y: (cy - pic.top) / pic.height };
  }
  snEl.addEventListener('pointerdown', e => {
    if (!sn || e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();
    snEl.setPointerCapture(e.pointerId);
    sn.from = snipAt(e); sn.sel = null;
    snEl.classList.add('drag');
  });
  snEl.addEventListener('pointermove', e => {
    if (!sn || !sn.from) return;
    const a = sn.from, b = snipAt(e);
    sn.sel = { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x), h: Math.abs(b.y - a.y) };
    snipDraw();
  });
  snEl.addEventListener('pointerup', e => {
    if (!sn || !sn.from) return;
    e.stopPropagation();
    sn.from = null;
    snEl.classList.remove('drag');
    const q = sn.sel;
    // a click (or a sliver) isn't a snip: keep the overlay up and let them drag again
    if (!q || q.w * sn.pic.width < 6 || q.h * sn.pic.height < 6) { sn.sel = null; snipDraw(); return; }
    snipEnd(true);
  });
  for (const ev of ['click', 'dblclick', 'mousedown', 'mouseup', 'contextmenu']) snEl.addEventListener(ev, e => { e.stopPropagation(); if (ev !== 'mousedown') e.preventDefault(); });
  function snipKey(e) {
    if (!sn) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); snipEnd(false); }
    else if (e.key === 'Enter') { e.preventDefault(); e.stopImmediatePropagation(); sn.sel = { x: 0, y: 0, w: 1, h: 1 }; snipEnd(true); }
    else if (!e.altKey && !e.ctrlKey && !e.metaKey) e.stopImmediatePropagation();   // keep the site's own shortcuts (space, k, j, l…) out while snipping
  }
  const snipMove = () => sn && snipDraw();
  async function startSnip(video, anchor) {
    if (sn) { snipEnd(false); return; }
    video = video || mainVideo();
    if (!video) return;
    anchor = anchor || (IS_YT && video.closest('#movie_player')) || video;
    const url = urlFor(video);
    if (!url) { toast(anchor, 'Open the video itself first', null, true); return; }
    if (!video.videoWidth) { toast(anchor, 'Let the video load first', null, true); return; }
    const wasPlaying = !video.paused;
    try { video.pause(); } catch {}
    sn = { video, anchor, url, time: video.currentTime, wasPlaying, src: {}, sel: null, from: null };
    srcEl.textContent = '';
    let fs = document.fullscreenElement;
    if (fs && fs.tagName === 'VIDEO') { await document.exitFullscreen().catch(() => {}); fs = null; }   // a bare <video> can't hold the overlay
    (fs || document.documentElement).appendChild(snipHost);
    snipDraw();
    addEventListener('keydown', snipKey, true);
    addEventListener('resize', snipMove, { passive: true });
    addEventListener('scroll', snipMove, { passive: true, capture: true });
    // the real source size (what the snip will be cut from), once pull. knows it; this also warms the stream link
    const me = sn;
    send({ type: 'formats', url }).then(r => {
      const i = r && r.ok && r.info;
      if (sn !== me || !i || !i.maxW) return;
      sn.src = { w: i.maxW, h: i.maxH };
      srcEl.textContent = `· source ${i.maxW}×${i.maxH}`;
      snipDraw();
    }).catch(() => {});
  }
  function snipEnd(take) {
    const s = sn;
    if (!s) return;
    sn = null;
    removeEventListener('keydown', snipKey, true);
    removeEventListener('resize', snipMove);
    removeEventListener('scroll', snipMove, true);
    const q = s.sel, pic = s.pic, vis = s.vis;
    if (take && q && pic && !still.matches) {
      // flash just the snipped part
      const fl = document.createElement('div');
      fl.className = 'fl';
      Object.assign(fl.style, { left: pic.left - vis.left + q.x * pic.width + 'px', top: pic.top - vis.top + q.y * pic.height + 'px', width: q.w * pic.width + 'px', height: q.h * pic.height + 'px' });
      snEl.classList.remove('has');
      snEl.appendChild(fl);
      snEl.style.pointerEvents = 'none';
      fl.animate([{ opacity: .85 }, { opacity: 0 }], { duration: 300, easing: 'ease-out', fill: 'forwards' }).finished
        .then(() => { fl.remove(); snipHost.remove(); snEl.style.pointerEvents = ''; }, () => snipHost.remove());
    } else snipHost.remove();
    if (s.wasPlaying) s.video.play().catch(() => {});
    if (!take || !q) return;
    const r4 = v => Math.round(v * 1e6) / 1e6;
    sendSnip(s, { x: r4(q.x), y: r4(q.y), w: r4(q.w), h: r4(q.h) });
  }
  async function sendSnip(s, crop) {
    toast(s.anchor, 'Snipping', 0, false, 0);
    const r = await send({ type: 'capture', url: s.url, title: cleanTitle(), time: s.time, crop, referer: window.top === window ? '' : (document.referrer || ''), fromPlayer: true });
    if (!r || !r.ok) { toast(s.anchor, (r && r.error) || 'pull. is not connected', null, true, 5000); return; }
    tJob = { id: r.id, anchor: s.anchor, snip: true };
  }
  chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'pullSnip' && window.top === window) startSnip(); });

  // ---------- trim: IN / OUT right on the player's timeline ----------
  // Two brackets on YouTube's own progress bar (other sites: a thin track of ours near the bottom of the video).
  // Dragging a bracket scrubs the video; I / O set the point at the playhead. The range is saved per video
  // (storage "trim"), so the popup's Range fields pick it up, and PULL downloads just IN → OUT.
  const fmtT = t => {
    const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + (s < 10 ? '0' : '') + s.toFixed(1);
  };
  const trimHost = document.createElement('div');
  trimHost.className = 'pull-trim';
  const xRoot = trimHost.attachShadow({ mode: 'open' });
  xRoot.innerHTML = `<style>
    .ui { position: absolute; inset: 0; pointer-events: none; transition: opacity .25s cubic-bezier(.33,0,.25,1); color: #f2f2f0;
          font: 600 11px/1 ui-monospace, "SF Mono", Consolas, monospace; letter-spacing: .06em; }
    .ui.hide { opacity: 0; } .ui.hide * { pointer-events: none !important; }
    .track { position: absolute; height: 4px; border-radius: 2px; background: rgba(255,255,255,.32); box-shadow: 0 0 0 1px rgba(0,0,0,.25); display: none; }
    .own .track { display: block; }
    .band { position: absolute; background: rgba(227,7,19,.38); box-shadow: inset 0 0 0 1px #E30713; border-radius: 1px; }
    .h { position: absolute; width: 20px; height: 28px; margin-left: -10px; pointer-events: auto; cursor: ew-resize; touch-action: none; }
    .h::before { content: ""; position: absolute; top: 4px; bottom: 4px; width: 5px; border: 3px solid #f2f2f0; filter: drop-shadow(0 0 1px rgba(0,0,0,.8)); }
    .h.in::before { left: 8px; border-right: 0; border-radius: 2px 0 0 2px; }
    .h.out::before { right: 8px; border-left: 0; border-radius: 0 2px 2px 0; }
    .h:hover::before, .h.drag::before { border-color: #fff; }
    .chip { position: absolute; display: flex; align-items: center; gap: 2px; padding: 4px 4px 4px 12px; border-radius: 999px; pointer-events: auto; white-space: nowrap;
            background: rgba(0,0,0,.82); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,.14); }
    .lg { font: 800 13px/1 ui-monospace, monospace; letter-spacing: .02em; margin-right: 6px; display: inline-flex; align-items: baseline; }
    .lg i { width: 4px; height: 4px; border-radius: 50%; background: #E30713; margin-left: 2px; display: inline-block; }
    button { all: unset; cursor: pointer; padding: 6px 8px; border-radius: 999px; color: rgba(242,242,240,.7); transition: background .2s, color .2s; }
    button b { color: #f2f2f0; font-weight: 700; margin-left: 3px; }
    button:hover { background: rgba(255,255,255,.12); color: #f2f2f0; }
    button:focus-visible { outline: 1px solid #E30713; }
    .len { color: rgba(242,242,240,.55); padding: 0 6px; }
    .go { background: #f2f2f0; color: #000; font-weight: 800; padding: 6px 11px; margin-left: 2px; }
    .go:hover { background: #fff; color: #000; }
    .x { padding: 6px 9px; }
    .h.pop::before { animation: hpop .5s cubic-bezier(.34,1.56,.64,1); }
    @keyframes hpop { 0% { transform: scaleY(1.35); } 55% { transform: scaleY(.9); } 100% { transform: none; } }
    .band { transition: background .3s; }
    .band.pop { animation: bpop .5s ease-out; }
    @keyframes bpop { 0% { background: rgba(227,7,19,.7); } 100% { background: rgba(227,7,19,.38); } }
    .len { font-variant-numeric: tabular-nums; transition: color .2s; display: inline-block; }
    .chip.live .len { color: #f2f2f0; }
    .len.pop { animation: lpop .45s cubic-bezier(.34,1.56,.64,1); }
    @keyframes lpop { 0% { transform: scale(1.22); } 100% { transform: none; } }
    @media (prefers-reduced-motion: reduce) { .h.pop::before, .band.pop, .len.pop { animation: none; } }
  </style><div class="ui hide" id="ui"><div class="track" id="xTrack"></div><div class="band" id="xBand"></div>
    <div class="h in" id="xHIn" title="IN — drag to trim"></div><div class="h out" id="xHOut" title="OUT — drag to trim"></div>
    <div class="chip" id="xChip"><span class="lg">pull<i></i></span>
      <button id="xIn" title="Set IN at the playhead (I)">IN<b id="vIn"></b></button>
      <button id="xOut" title="Set OUT at the playhead (O)">OUT<b id="vOut"></b></button>
      <span class="len" id="xLen"></span>
      <button id="xLoop" title="Make a looping GIF / WebP of IN → OUT (up to 30 s)">GIF</button>
      <button class="go" id="xGo" title="Download only IN → OUT">PULL ↓</button>
      <button class="x" id="xX" title="Clear IN / OUT">✕</button></div></div>`;
  const $x = id => xRoot.getElementById(id);
  const xUi = $x('ui'), xTrack = $x('xTrack'), xBand = $x('xBand'), xHIn = $x('xHIn'), xHOut = $x('xHOut'), xChip = $x('xChip');
  // on YouTube the overlay lives inside the player (so it shows in fullscreen and keeps the controls awake);
  // clicks must not reach the player or it would pause / play
  for (const ev of ['pointerdown', 'mousedown', 'mouseup', 'click', 'dblclick', 'contextmenu', 'touchstart'])
    trimHost.addEventListener(ev, e => e.stopPropagation());

  let tr = null;   // { video, player, anchor, btn, key, url, start, end, drag, moved, pending }
  let trRaf = 0;
  function trimTrack() {
    const hr = trimHost.getBoundingClientRect();
    if (IS_YT) {
      const bar = tr.player.querySelector('.ytp-progress-bar') || tr.player.querySelector('.ytp-progress-bar-container');
      const r = bar && bar.getBoundingClientRect();
      if (!r || r.width < 40) return null;
      return { x: r.left - hr.left, y: r.top - hr.top + r.height / 2, w: r.width, h: Math.max(3, Math.min(r.height, 8)), own: false };
    }
    const r = tr.video.getBoundingClientRect();
    if (r.width < 160 || r.height < 100) return null;
    return { x: r.left - hr.left + 16, y: r.bottom - hr.top - (r.height > 240 ? 64 : 36), w: r.width - 32, h: 4, own: true };
  }
  function mountTrim() {
    trimHost.style.cssText = IS_YT ? 'position:absolute;inset:0;z-index:70;pointer-events:none'
                                   : 'position:fixed;inset:0;z-index:2147483645;pointer-events:none';
    (IS_YT ? tr.player : document.documentElement).appendChild(trimHost);
  }
  function trimDraw() {
    trRaf = 0;
    if (!tr) return;
    const here = IS_YT && Sites.parse(location.href);
    if (!tr.video.isConnected || (IS_YT && (!here || here.key !== tr.key))) { trimClose(false); return; }
    if (!trimHost.isConnected) mountTrim();
    const d = tr.video.duration, k = trimTrack();
    const hide = !k || !isFinite(d) || d <= 0 || (!tr.drag && IS_YT && tr.player.classList.contains('ytp-autohide'));
    xUi.classList.toggle('hide', hide);
    if (!hide) {
      xUi.classList.toggle('own', k.own);
      const X = t => k.x + Math.max(0, Math.min(1, t / d)) * k.w;
      const a = X(tr.start), b = X(tr.end);
      Object.assign(xTrack.style, { left: k.x + 'px', top: k.y - 2 + 'px', width: k.w + 'px' });
      Object.assign(xBand.style, { left: a + 'px', width: Math.max(2, b - a) + 'px', top: k.y - k.h / 2 - 1 + 'px', height: k.h + 2 + 'px' });
      Object.assign(xHIn.style, { left: a + 'px', top: k.y - 14 + 'px' });
      Object.assign(xHOut.style, { left: b + 'px', top: k.y - 14 + 'px' });
      const cw = xChip.offsetWidth, hw = trimHost.clientWidth;
      Object.assign(xChip.style, { top: k.y - 54 + 'px', left: Math.max(8, Math.min(hw - cw - 8, a - 12)) + 'px' });
      $x('vIn').textContent = fmtT(tr.start);
      $x('vOut').textContent = fmtT(tr.end);
      $x('xLen').textContent = '= ' + (tr.end - tr.start).toFixed(1) + 's';
      xChip.classList.toggle('live', !!tr.drag);
    }
    trRaf = requestAnimationFrame(trimDraw);
  }
  function trimSave() {
    if (!tr) return;
    chrome.storage.local.set({ trim: { key: tr.key, url: tr.url, start: +tr.start.toFixed(3), end: +tr.end.toFixed(3), at: Date.now() } }).catch(() => {});
  }
  function seek(t) {
    const v = tr.video;
    tr.pending = t;
    if (!v.seeking) v.currentTime = t;
  }
  function onSeeked() { if (tr && tr.pending != null && Math.abs(tr.video.currentTime - tr.pending) > .05) tr.video.currentTime = tr.pending; else if (tr) tr.pending = null; }
  function setPoint(which) {
    if (!tr) return;
    const v = tr.video, d = v.duration, t = v.currentTime;
    if (!isFinite(d)) return;
    if (which === 'in') { tr.start = Math.min(t, d - .1); if (tr.end <= tr.start + .1) tr.end = d; }
    else { tr.end = Math.max(t, .1); if (tr.start >= tr.end - .1) tr.start = 0; }
    trimSave();
  }
  function bindHandle(el, which) {
    el.addEventListener('pointerdown', e => {
      if (!tr) return;
      e.preventDefault();
      el.setPointerCapture(e.pointerId);
      el.classList.add('drag');
      tr.drag = which; tr.moved = false;
      if (!tr.video.paused) tr.video.pause();
    });
    el.addEventListener('pointermove', e => {
      if (!tr || tr.drag !== which) return;
      const k = trimTrack(), d = tr.video.duration;
      if (!k || !isFinite(d)) return;
      const hr = trimHost.getBoundingClientRect();
      let t = Math.max(0, Math.min(d, (e.clientX - hr.left - k.x) / k.w * d));
      if (which === 'in') tr.start = t = Math.min(t, tr.end - .1); else tr.end = t = Math.max(t, tr.start + .1);
      tr.moved = true;
      seek(t);
    });
    const up = () => {
      el.classList.remove('drag');
      if (!tr || tr.drag !== which) return;
      tr.drag = null;
      if (!tr.moved) seek(which === 'in' ? tr.start : tr.end);
      trimSave();
      // a small spring as the bracket lands
      for (const n of [el, xBand, $x('xLen')]) { n.classList.remove('pop'); void n.offsetWidth; n.classList.add('pop'); }
    };
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  }
  bindHandle(xHIn, 'in');
  bindHandle(xHOut, 'out');
  $x('xIn').addEventListener('click', () => setPoint('in'));
  $x('xOut').addEventListener('click', () => setPoint('out'));
  $x('xX').addEventListener('click', () => { chrome.storage.local.remove('trim').catch(() => {}); trimClose(false); });
  $x('xGo').addEventListener('click', async () => {
    if (!tr) return;
    const a = tr.anchor, section = { start: +tr.start.toFixed(3), end: +tr.end.toFixed(3) };
    toast(a, 'Adding range…', 0, false, 0);
    const r = await send({ type: 'download', url: tr.url, title: cleanTitle(), fromPlayer: true, options: { section } });
    if (!r || !r.ok) { toast(a, (r && r.error) || 'pull. is not connected', null, true, 5000); return; }
    tJob = { id: r.id, anchor: a };
    toast(a, 'Range ' + fmtT(section.start) + ' → ' + fmtT(section.end) + ' queued', 0, false, 0);
  });
  let loopFmt = 'gif';
  const loopLabel = () => { $x('xLoop').textContent = loopFmt.toUpperCase(); };
  chrome.storage.local.get('settings').then(({ settings }) => { loopFmt = settings?.loopFmt === 'webp' ? 'webp' : 'gif'; loopLabel(); }).catch(() => {});
  chrome.storage.onChanged.addListener(ch => { if (ch.settings) { loopFmt = ch.settings.newValue?.loopFmt === 'webp' ? 'webp' : 'gif'; loopLabel(); } });
  $x('xLoop').addEventListener('click', async () => {
    if (!tr) return;
    const a = tr.anchor, start = +tr.start.toFixed(3), end = +tr.end.toFixed(3);
    if (end - start > 30) { toast(a, 'Loops are up to 30 s — tighten IN / OUT', null, true, 4000); return; }
    toast(a, 'Making ' + loopFmt.toUpperCase() + '…', 0, false, 0);
    const r = await send({ type: 'loop', url: tr.url, title: cleanTitle(), start, end, fromPlayer: true });
    if (!r || !r.ok) { toast(a, (r && r.error) || 'pull. is not connected', null, true, 5000); return; }
    tJob = { id: r.id, anchor: a };
  });
  addEventListener('keydown', e => {
    if (!tr || e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
    const k = e.key.toLowerCase();
    if (k !== 'i' && k !== 'o') return;
    const t = e.composedPath()[0];
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    e.preventDefault(); e.stopImmediatePropagation();
    setPoint(k === 'i' ? 'in' : 'out');
  }, true);

  async function toggleTrim(video, anchor, btn) {
    if (tr) { trimClose(false); return; }
    const url = video && urlFor(video), p = url && Sites.parse(url);
    if (!p) { toast(anchor, 'Open the video itself first', null, true); return; }
    const d = video.duration;
    if (!isFinite(d) || d <= 0) { toast(anchor, 'Wait for the video to load — live streams can’t be trimmed', null, true); return; }
    let saved = null;
    try { saved = (await chrome.storage.local.get('trim')).trim; } catch {}
    tr = { video, player: IS_YT ? anchor : null, anchor, btn, key: p.key, url: p.url, drag: null, pending: null };
    if (saved && saved.key === p.key && saved.end > saved.start && Date.now() - (saved.at || 0) < 12 * 3600e3) { tr.start = Math.min(saved.start, d - .1); tr.end = Math.min(saved.end, d); }
    else { const t = video.currentTime; tr.start = t < d - 1 ? t : 0; tr.end = d; }
    video.addEventListener('seeked', onSeeked);
    if (btn) btn.classList.add('on');
    mountTrim();
    trimSave();
    toast(anchor, 'Drag the brackets · I / O at the playhead', null, false, 3200);
    if (!trRaf) trRaf = requestAnimationFrame(trimDraw);
  }
  function trimClose() {
    if (!tr) return;
    tr.video.removeEventListener('seeked', onSeeked);
    if (tr.btn) tr.btn.classList.remove('on');
    tr = null;
    xUi.classList.add('hide');
    trimHost.remove();
  }
  chrome.storage.onChanged.addListener(ch => {
    if (!ch.trim || !tr) return;
    const v = ch.trim.newValue;
    if (!v) { trimClose(); return; }
    if (v.key === tr.key && !tr.drag) { tr.start = v.start; tr.end = v.end; }
  });

  // ---------- YouTube: native buttons ----------
  // Our own small group at the start of the right-hand controls, centred on the bar and sized like
  // YouTube's buttons. It never goes inside YouTube's groups, so their layout changes can't push it around.
  const ytCSS = document.createElement('style');
  ytCSS.textContent = `.pull-yt-wrap { display: inline-flex !important; align-items: center !important; justify-content: center; flex: none; align-self: center;
      vertical-align: top; height: 100%; box-sizing: border-box; position: relative; float: none; }
    .pull-yt-wrap > .pull-yt.ytp-button { position: relative !important; display: inline-flex !important; flex: none; align-items: center; justify-content: center;
      margin: 0 !important; padding: 0 !important; float: none; vertical-align: top; line-height: 0 !important; opacity: .92; transition: opacity .2s; box-sizing: border-box; }
    .pull-yt.ytp-button:hover { opacity: 1; }
    .pull-yt.ytp-button.on { opacity: 1; background: rgba(227,7,19,.32) !important; border-radius: 999px !important; }`;
  // The icon is a custom element with its SVG in a shadow root, centred with inset/margin (no transform) and
  // inline !important styles, so nothing in YouTube's CSS (svg sizing, transforms on button children) can move it.
  function ytIcon(svg, pct, max) {
    const i = document.createElement('pull-i');
    const css = { position: 'absolute', inset: '0', margin: 'auto', width: pct + '%', height: pct + '%', 'max-width': max + 'px', 'max-height': max + 'px',
                  display: 'block', padding: '0', border: '0', transform: 'none', 'pointer-events': 'none', transition: 'scale .25s cubic-bezier(.33,0,.25,1)' };
    for (const [k, v] of Object.entries(css)) i.style.setProperty(k, v, 'important');
    i.attachShadow({ mode: 'open' }).innerHTML = `<style>:host{line-height:0}svg{display:block;width:100%;height:100%}</style>${svg}`;
    return i;
  }
  const visible = el => el && el.offsetWidth > 4 && el.offsetHeight > 4;
  const isPill = cs => cs.backgroundColor && !/^(transparent|rgba\([^)]*,\s*0\))$/.test(cs.backgroundColor) && parseFloat(cs.borderRadius) > 4;
  function ytInject() {
    if (!enabled) return;
    const player = document.querySelector('#movie_player') || document.querySelector('.html5-video-player');
    const right = player && player.querySelector('.ytp-right-controls');
    if (!right || player.querySelector('.pull-yt-wrap')) return;
    if (!ytCSS.isConnected) document.head.appendChild(ytCSS);
    const video = () => player.querySelector('video');
    const mk = (cls, title, svg, fn) => {
      const b = document.createElement('button');
      b.className = 'ytp-button pull-yt ' + cls;
      b.title = title; b.setAttribute('aria-label', title);
      const ic = ytIcon(svg, cls === 'dl' ? 46 : 54, cls === 'dl' ? 24 : 27);
      b.appendChild(ic);
      b.addEventListener('pointerdown', () => ic.style.setProperty('scale', '.88', 'important'));
      for (const ev of ['pointerup', 'pointerleave']) b.addEventListener(ev, () => ic.style.setProperty('scale', '1', 'important'));
      b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); fn(video(), player); });
      return b;
    };
    const wrap = document.createElement('div');
    wrap.className = 'pull-yt-wrap';
    const bDl = mk('dl', 'pull. — download this video', arrowSVG(28, 4, 0, 0, 1.8), doPull);
    const bCap = mk('cap', 'pull. — capture this frame (full res)', CAPTURE(28), doCapture);
    const bSnip = mk('snip', 'pull. — snip a part of the frame, full res (Alt+Shift+X)', SNIP(28), v => startSnip(v, player));
    const bTrim = mk('trim', 'pull. — set IN / OUT on the timeline (I / O)', TRIM(28), v => toggleTrim(v, player, bTrim));
    wrap.append(bDl, bCap, bSnip, bTrim);
    right.insertBefore(wrap, right.firstChild);
    // match YouTube's own button box and, on the new player, its rounded group
    const sync = () => {
      const anchor = [...right.querySelectorAll('.ytp-subtitles-button, .ytp-settings-button, .ytp-size-button, .ytp-fullscreen-button')]
        .find(el => !wrap.contains(el) && visible(el));
      if (!anchor) return;
      const r = anchor.getBoundingClientRect();
      const w = Math.round(r.width), h = Math.round(r.height);
      for (const b of [bDl, bCap, bSnip, bTrim]) { b.style.width = w + 'px'; b.style.height = h + 'px'; }
      let pill = null;
      for (let el = anchor.parentElement; el && el !== right.parentElement; el = el.parentElement) {
        const cs = getComputedStyle(el);
        if (isPill(cs)) { pill = { el, cs }; break; }
        if (el === right) break;
      }
      const ws = wrap.style;
      if (pill) {
        const pr = pill.el.getBoundingClientRect();
        ws.height = Math.round(pr.height) + 'px';
        ws.background = pill.cs.backgroundColor;
        ws.borderRadius = pill.cs.borderRadius;
        ws.backdropFilter = pill.cs.backdropFilter; ws.webkitBackdropFilter = pill.cs.webkitBackdropFilter || pill.cs.backdropFilter;
        ws.padding = `0 ${pill.cs.paddingRight}`;
        ws.marginRight = (parseFloat(getComputedStyle(right).columnGap) || 0) ? '0' : '8px';
      } else {
        ws.height = h + 'px'; ws.background = ''; ws.borderRadius = ''; ws.padding = '0'; ws.marginRight = '0';
      }
    };
    sync();
    const ro = new ResizeObserver(() => sync());
    ro.observe(right);
    setTimeout(sync, 800); setTimeout(sync, 2500);
  }
  function ytRemove() { trimClose(); document.querySelectorAll('.pull-yt-wrap, .pull-yt').forEach(b => b.remove()); }

  // ---------- other sites: hover bar over the video ----------
  const bar = document.createElement('div');
  bar.style.cssText = 'position:fixed;z-index:2147483646;top:0;left:0;display:none';
  const bRoot = bar.attachShadow({ mode: 'open' });
  bRoot.innerHTML = `<style>
    .bar { display: flex; gap: 4px; padding: 4px; border-radius: 999px; background: rgba(0,0,0,.72); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
           border: 1px solid rgba(255,255,255,.14); opacity: 0; transform: translateY(-4px); transition: opacity .25s cubic-bezier(.33,0,.25,1), transform .35s cubic-bezier(.33,0,.25,1); }
    .bar.on { opacity: 1; transform: none; }
    button { all: unset; cursor: pointer; width: 34px; height: 34px; border-radius: 50%; display: grid; place-items: center; transition: background .2s, transform .25s cubic-bezier(.33,0,.25,1); }
    button:hover { background: rgba(255,255,255,.14); }
    button:active { transform: scale(.9); }
    button.on { background: rgba(227,7,19,.35); }
    button:focus-visible { outline: 2px solid #E30713; outline-offset: 1px; }
    .i { width: 20px; height: 20px; display: block; } .cap .i { width: 24px; height: 24px; }
  </style><div class="bar" id="bar"><button class="dl" id="bDl" title="pull. — download this video" aria-label="pull. — download this video"><span class="i">${arrowSVG(28, 4, 0, 0, 1.55)}</span></button><button class="cap" id="bCap" title="pull. — capture this frame (full res)" aria-label="pull. — capture this frame (full res)"><span class="i">${CAPTURE(28)}</span></button><button class="cap" id="bSnip" title="pull. — snip a part of the frame, full res (Alt+Shift+X)" aria-label="pull. — snip a part of the frame"><span class="i">${SNIP(28)}</span></button><button class="cap" id="bTrim" title="pull. — set IN / OUT on the timeline (I / O)" aria-label="pull. — set IN / OUT on the timeline"><span class="i">${TRIM(28)}</span></button></div>`;
  const barEl = bRoot.getElementById('bar');
  let cur = null, hideT = 0;
  function placeBar() {
    if (!cur || !cur.isConnected) { hideBar(true); return; }
    const r = cur.getBoundingClientRect();
    if (r.width < 200 || r.height < 120 || r.bottom < 0 || r.top > innerHeight) { hideBar(true); return; }
    bar.style.top = Math.max(6, r.top + 10) + 'px';
    bar.style.left = Math.min(innerWidth - 166, r.right - 162) + 'px';
  }
  function showBar(v) {
    if (!enabled) return;
    clearTimeout(hideT);
    cur = v;
    if (!bar.isConnected) document.documentElement.appendChild(bar);
    bar.style.display = 'block'; placeBar();
    requestAnimationFrame(() => barEl.classList.add('on'));
  }
  function hideBar(now) {
    clearTimeout(hideT);
    const go = () => { barEl.classList.remove('on'); setTimeout(() => { if (!barEl.classList.contains('on')) bar.style.display = 'none'; }, 260); };
    if (now) go(); else hideT = setTimeout(go, 700);
  }
  let vids = [], vidsAt = 0;
  function videoUnder(x, y) {
    if (performance.now() - vidsAt > 800) { vids = [...document.getElementsByTagName('video')]; vidsAt = performance.now(); }
    for (const v of vids) {
      const r = v.getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom && r.width >= 200 && r.height >= 120) return v;
    }
    return null;
  }
  if (!IS_YT) {
    let raf = 0;
    addEventListener('pointermove', e => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        if (e.composedPath().includes(bar)) { clearTimeout(hideT); return; }
        const v = videoUnder(e.clientX, e.clientY);
        if (v) showBar(v); else if (cur) hideBar(false);
      });
    }, { passive: true, capture: true });
    addEventListener('scroll', () => cur && placeBar(), { passive: true, capture: true });
    bRoot.getElementById('bDl').addEventListener('click', e => { e.stopPropagation(); if (cur) doPull(cur, cur); });
    bRoot.getElementById('bCap').addEventListener('click', e => { e.stopPropagation(); if (cur) doCapture(cur, cur); });
    bRoot.getElementById('bSnip').addEventListener('click', e => { e.stopPropagation(); if (cur) { hideBar(true); startSnip(cur, cur); } });
    const bTrimO = bRoot.getElementById('bTrim');
    bTrimO.addEventListener('click', e => { e.stopPropagation(); if (cur) toggleTrim(cur, cur, bTrimO); });
  }

  // ---------- settings + YouTube page changes ----------
  function apply() {
    if (IS_YT) { if (enabled) ytInject(); else ytRemove(); }
    else if (!enabled) { hideBar(true); trimClose(); }
  }
  chrome.storage.local.get('settings').then(({ settings }) => { enabled = !settings || settings.inPlayer !== false; apply(); }).catch(() => apply());
  chrome.storage.onChanged.addListener(ch => { if (ch.settings) { enabled = ch.settings.newValue?.inPlayer !== false; apply(); } });
  if (IS_YT) {
    // watch the DOM only until the player shows up; after that a cheap check covers YouTube re-rendering its controls
    addEventListener('yt-navigate-finish', () => setTimeout(ytInject, 50));
    let pend = 0;
    const mo = new MutationObserver(() => {
      if (pend) return;
      pend = setTimeout(() => { pend = 0; ytInject(); if (document.querySelector('.pull-yt')) mo.disconnect(); }, 300);
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setInterval(() => { if (enabled && !document.hidden && !document.querySelector('.pull-yt')) ytInject(); }, 1500);
  }
})();
