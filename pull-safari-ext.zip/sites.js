// pull. — which pages we understand. Shared by background.js (importScripts) and popup.js.
// parse(url) -> { site, key, url, id?, title?, thumb?, isPlaylist?, playlistOnly?, badge? } | null

const Sites = (() => {
  const yt = (u, host) => {
    let id = null;
    if (host === 'youtu.be') id = u.pathname.slice(1).split('/')[0];
    else if (host === 'youtube.com' || host === 'music.youtube.com') {
      if (u.pathname === '/watch') id = u.searchParams.get('v');
      else if (/^\/(shorts|live|embed)\//.test(u.pathname)) id = u.pathname.split('/')[2];
      else if (u.pathname === '/playlist' && u.searchParams.get('list'))
        return { site: 'youtube', key: 'ytpl:' + u.searchParams.get('list'), url: 'https://www.youtube.com/playlist?list=' + u.searchParams.get('list'),
                 isPlaylist: true, playlistOnly: true, badge: 'PLAYLIST' };
    } else return undefined;
    if (!id) return null;
    const list = u.searchParams.get('list');
    return {
      site: 'youtube', id, key: 'yt:' + id,
      url: 'https://www.youtube.com/watch?v=' + id + (list ? '&list=' + list : ''),
      isPlaylist: !!list, badge: u.pathname.startsWith('/shorts/') ? 'SHORT' : '',
      thumb: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    };
  };

  const fb = (u, host) => {
    if (host === 'fb.watch') {
      const code = u.pathname.split('/')[1];
      return code ? { site: 'facebook', key: 'fbw:' + code, url: 'https://fb.watch/' + code + '/', needsResolve: true } : null;
    }
    if (!/(^|\.)facebook\.com$/.test(host)) return undefined;
    const p = u.pathname;
    let m;
    if ((p === '/watch/' || p === '/watch') && u.searchParams.get('v'))
      return { site: 'facebook', id: u.searchParams.get('v'), key: 'fb:' + u.searchParams.get('v'), url: 'https://www.facebook.com/watch/?v=' + u.searchParams.get('v') };
    if ((m = p.match(/^\/reels?\/(\d+)/)))
      return { site: 'facebook', id: m[1], key: 'fb:' + m[1], url: 'https://www.facebook.com/reel/' + m[1], badge: 'REEL' };
    if ((m = p.match(/\/videos\/(?:[^/]+\/)?(\d{6,})/)))
      return { site: 'facebook', id: m[1], key: 'fb:' + m[1], url: 'https://www.facebook.com/watch/?v=' + m[1] };
    if ((m = p.match(/^\/share\/(v|r)\/([^/]+)/)))
      return { site: 'facebook', key: 'fbs:' + m[2], url: 'https://www.facebook.com/share/' + m[1] + '/' + m[2] + '/', badge: m[1] === 'r' ? 'REEL' : '', needsResolve: true };
    return null;
  };

  const tt = (u, host) => {
    if (!/(^|\.)tiktokv?\.com$/.test(host)) return undefined;
    const p = u.pathname;
    let m;
    const video = (id, user) => ({ site: 'tiktok', id, key: 'tt:' + id, url: `https://www.tiktok.com/@${user || '_'}/video/${id}` });
    // short links (vm. / vt. / /t/) redirect to the real video
    if (/^(vm|vt)\.tiktok\.com$/.test(u.hostname) || /^\/t\/[^/]+/.test(p)) {
      const code = /^\/t\//.test(p) ? p.split('/')[2] : p.split('/')[1];
      return code ? { site: 'tiktok', key: 'tts:' + code, url: u.origin + p.replace(/\/?$/, '/'), needsResolve: true } : null;
    }
    if ((m = p.match(/^\/@([\w.-]+)\/video\/(\d+)/))) return video(m[2], m[1]);
    if ((m = p.match(/^\/(?:share\/video|embed(?:\/v2)?|v)\/(\d+)/))) return video(m[1]);   // share / embed / m.tiktok.com/v/ID.html
    return null; // feed, profile, photo posts, live
  };

  const vm = (u, host) => {
    const parts = u.pathname.split('/').filter(Boolean);
    if (host === 'player.vimeo.com') {
      if (parts[0] !== 'video' || !/^\d+$/.test(parts[1] || '')) return null;
      const h = u.searchParams.get('h');
      return { site: 'vimeo', id: parts[1], key: 'vm:' + parts[1], url: `https://player.vimeo.com/video/${parts[1]}` + (h ? `?h=${h}` : '') };
    }
    if (host !== 'vimeo.com') return undefined;
    let i = parts.findIndex(x => x === 'video' || x === 'videos');
    i = i >= 0 && /^\d+$/.test(parts[i + 1] || '') ? i + 1 : -1;
    if (i < 0 && parts[0] === 'showcase' && /^\d+$/.test(parts[1] || ''))
      return { site: 'vimeo', key: 'vms:' + parts[1], url: `https://vimeo.com/showcase/${parts[1]}`, isPlaylist: true, playlistOnly: true, badge: 'SHOWCASE' };
    if (i < 0 && !['showcase', 'album', 'user', 'manage', 'settings', 'upload', 'watch', 'search'].includes(parts[0]))
      i = parts.findIndex(x => /^\d{5,}$/.test(x));
    if (i < 0) return null;
    const id = parts[i];
    const hash = /^[0-9a-f]{6,}$/.test(parts[i + 1] || '') ? parts[i + 1] : u.searchParams.get('h');   // unlisted videos
    return { site: 'vimeo', id, key: 'vm:' + id, url: `https://vimeo.com/${id}` + (hash ? `/${hash}` : '') };
  };

  // Instagram: reels and video posts (/reel/, /reels/, /p/, /tv/, also /{user}/reel/)
  const ig = (u, host) => {
    if (!/(^|\.)instagram\.com$/.test(host)) return undefined;
    const m = u.pathname.match(/^\/(?:[\w.]+\/)?(reels?|p|tv)\/([\w-]{5,})/);
    if (!m) return null;
    const kind = m[1] === 'p' ? 'p' : m[1] === 'tv' ? 'tv' : 'reel';
    return { site: 'instagram', id: m[2], key: 'ig:' + m[2], url: `https://www.instagram.com/${kind}/${m[2]}/`, badge: kind === 'reel' ? 'REEL' : '' };
  };

  // Pinterest: video pins and image pins (any country domain: th.pinterest.com, pinterest.co.uk…) + pin.it short links
  const pin = (u, host) => {
    if (host === 'pin.it') {
      const code = u.pathname.split('/')[1];
      return code ? { site: 'pinterest', key: 'pins:' + code, url: 'https://pin.it/' + code, needsResolve: true } : null;
    }
    if (!/(^|\.)pinterest\.(com|ca|co\.uk|com\.au|de|fr|es|it|jp|co\.kr|com\.mx|nz|ch|at|cl|pt|ph|dk|nl|ie|in|co\.in|id|vn|com\.vn|ru|se|nl)$/.test(host)) return undefined;
    const m = u.pathname.match(/\/pin\/(?:[\w-]+--)?(\d{6,})/);
    if (!m) return null;
    return { site: 'pinterest', id: m[1], key: 'pin:' + m[1], url: `https://www.pinterest.com/pin/${m[1]}/` };
  };

  function parse(raw) {
    let u;
    try { u = new URL(raw); } catch { return null; }
    if (!/^https?:$/.test(u.protocol)) return null;
    const host = u.hostname.replace(/^(www|m|web|mbasic|vm|vt)\./, '');
    for (const f of [yt, fb, tt, vm, ig, pin]) {
      const r = f(u, host);
      if (r !== undefined) return r;
    }
    return null;
  }

  // any other link the user pastes: let yt-dlp try (Instagram, X, TikTok, Vimeo…)
  function parseAny(raw) {
    const r = parse(raw);
    if (r) return r;
    try {
      const u = new URL(raw.trim());
      if (!/^https?:$/.test(u.protocol)) return null;
      return { site: 'other', key: 'url:' + u.href, url: u.href };
    } catch { return null; }
  }

  const isSupportedPage = raw => {
    try { return /(^|\.)(youtube\.com|youtu\.be|facebook\.com|fb\.watch|tiktok\.com|vimeo\.com|instagram\.com|pin\.it)$/.test(new URL(raw).hostname) || /(^|\.)pinterest\.[a-z.]+$/.test(new URL(raw).hostname); } catch { return false; }
  };

  return { parse, parseAny, isSupportedPage };
})();

// runs inside the page: find the video the user is looking at (most visible <video>)
// action 'state' -> { t, paused, vw, vh, dur, link }   action 'grab' -> { data, w, h, t } (on-screen quality)
function pullPageVideo(action, fmt) {
  const vids = [...document.querySelectorAll('video')].filter(v => v.readyState > 0 && v.videoWidth > 0);
  if (!vids.length) return null;
  const vis = v => {
    const r = v.getBoundingClientRect();
    const w = Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
    const h = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
    return w * h;
  };
  vids.sort((a, b) => vis(b) - vis(a));
  const v = vids[0];
  if (action === 'grab') {
    try {
      const c = document.createElement('canvas');
      c.width = v.videoWidth; c.height = v.videoHeight;
      c.getContext('2d').drawImage(v, 0, 0);
      return { data: c.toDataURL(fmt === 'jpg' ? 'image/jpeg' : 'image/png', 0.95), w: c.width, h: c.height, t: v.currentTime };
    } catch (e) { return { error: String(e) }; }
  }
  // Facebook feed: the page URL isn't the video's, so look for the video's own permalink nearby
  let link = null;
  if (/facebook\.com$/.test(location.hostname)) {
    const sel = 'a[href*="/videos/"],a[href*="/reel/"],a[href*="/watch/?v="],a[href*="/watch?v="]';
    for (let el = v, d = 0; el && d < 30 && !link; el = el.parentElement, d++) {
      const a = el.querySelector && el.querySelector(sel);
      if (a) link = a.href;
    }
  }
  // Instagram feed: the post's own /reel/ or /p/ link sits in the same <article>
  if (/instagram\.com$/.test(location.hostname)) {
    const sel = 'a[href*="/reel/"],a[href*="/p/"],a[href*="/tv/"]';
    for (let el = v, d = 0; el && d < 30 && !link; el = el.parentElement, d++) {
      const a = el.querySelector && el.querySelector(sel);
      if (a) link = a.href;
    }
  }
  // Pinterest home / board grid: the pin's own link sits on its card
  if (/pinterest\./.test(location.hostname) && !/\/pin\/\d/.test(location.pathname)) {
    for (let el = v, d = 0; el && d < 25 && !link; el = el.parentElement, d++) {
      const a = el.querySelector && el.querySelector('a[href*="/pin/"]');
      if (a) link = a.href;
    }
  }
  // TikTok feed (For You / Following): the player wrapper's id ends with the video id
  if (/tiktok\.com$/.test(location.hostname)) {
    for (let el = v, d = 0; el && d < 25 && !link; el = el.parentElement, d++) {
      const m = (el.id || '').match(/(?:^|[-_])(\d{15,21})$/);
      if (m) { link = 'https://www.tiktok.com/@_/video/' + m[1]; break; }
      const a = el.querySelector && el.querySelector('a[href*="/video/"]');
      if (a) link = a.href;
    }
  }
  return { t: v.currentTime, paused: v.paused, vw: v.videoWidth, vh: v.videoHeight, dur: v.duration, link };
}

// runs inside a tiktok.com tab: read the post the way TikTok's own player does, with the user's session.
// Works for posts yt-dlp gets blocked on (TikTok Shop / commerce posts, region-limited, logged-in-only).
async function pullTikTokItem(id) {
  const abs = u => (u && u.startsWith('//') ? 'https:' + u : u);
  const out = { id, formats: [], ua: navigator.userAgent };
  const fromJSON = html => {
    const m = html.match(/<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/);
    if (m) {
      try {
        const d = (JSON.parse(m[1]).__DEFAULT_SCOPE__ || {})['webapp.video-detail'] || {};
        out.status = d.statusCode;
        const it = d.itemInfo && d.itemInfo.itemStruct;
        if (it && String(it.id) === String(id)) return it;
      } catch {}
    }
    const s = html.match(/<script[^>]+id="SIGI_STATE"[^>]*>([\s\S]*?)<\/script>/);
    if (s) { try { const j = JSON.parse(s[1]); return j.ItemModule && j.ItemModule[id]; } catch {} }
    return null;
  };
  let item = null;
  try {
    const r = await fetch('https://www.tiktok.com/@_/video/' + id, { credentials: 'include' });
    item = fromJSON(await r.text());
  } catch (e) { out.error = String(e); }
  // the tab may have been opened right on this post
  if (!item) item = fromJSON(document.documentElement.innerHTML);

  if (item && item.video) {
    const v = item.video, W = +v.width || 0, H = +v.height || 0, ratio = W && H ? W / H : 0.5625;
    for (const b of v.bitrateInfo || []) {
      const pa = b.PlayAddr || {};
      const km = (pa.UrlKey || '').match(/v[^_]+_([^_]+)_(\d+)p_(\d+)/);
      const codec = String((km && km[1]) || b.CodecType || 'h264');
      if (/bytevc2/i.test(codec)) continue;                       // ByteDance's own codec — unplayable
      let w = +pa.Width || 0, h = +pa.Height || 0;
      if (!w && km) {
        let dim = +km[2]; if (dim === 540) dim = 576;
        if (ratio < 1) { w = dim; h = Math.round(dim / ratio / 2) * 2; } else { h = dim; w = Math.round(dim * ratio / 2) * 2; }
      }
      for (const u0 of pa.UrlList || []) {
        const url = abs(u0);
        try { if (/\/media-video-hvc1\/?$/.test(new URL(url).pathname)) continue; } catch { continue; } // video-only
        out.formats.push({ url, w, h, codec: /265|bytevc1|hevc|hvc/i.test(codec) ? 'h265' : 'h264', br: +b.Bitrate || 0, size: +pa.DataSize || 0 });
      }
    }
    const play = typeof v.playAddr === 'string' ? [v.playAddr] : (v.playAddr || []).map(x => x && x.src);
    for (const u of play.filter(Boolean)) out.formats.push({ url: abs(u), w: W, h: H, codec: 'h264', br: 0, play: true });
    out.title = item.desc || '';
    out.uploader = (item.author && (item.author.uniqueId || item.author.nickname)) || item.author || '';
    out.duration = +v.duration || 0;
    out.cover = abs(v.originCover || v.cover || '');
  }
  // last resort: whatever the page's player is showing for this post (watermark-free play address)
  for (const el of document.querySelectorAll('video')) {
    const src = el.currentSrc || el.src;
    if (!/^https?:/.test(src || '')) continue;
    let mine = location.pathname.includes(id);
    for (let p = el, d = 0; p && d < 25 && !mine; p = p.parentElement, d++) if ((p.id || '').endsWith(id)) mine = true;
    if (mine) out.formats.push({ url: src, w: el.videoWidth, h: el.videoHeight, codec: 'h264', br: 0, play: true, fromPlayer: true });
  }
  return out;
}

// runs inside any page: embedded Vimeo players (client portfolios, review pages…)
function pullFindEmbeds() {
  const found = [];
  for (const f of document.querySelectorAll('iframe[src*="player.vimeo.com/video/"], iframe[data-src*="player.vimeo.com/video/"]')) {
    const r = f.getBoundingClientRect();
    found.push({ src: f.src || f.dataset.src, area: Math.max(0, r.width) * Math.max(0, r.height) });
  }
  return found.sort((a, b) => b.area - a.area).map(x => x.src);
}
